import mymodule
mymodule.greeting("Mike")
"""
#import ImageSAVER
#ImageSAVER.imageSaver("a premium beautiful wallpapers sunrises",1)

import PlainTextFromURL as pturl
link = "https://en.wikipedia.org/wiki/Brewing"
text = pturl.PlainTextFromURL(link,return_summary=True,open_in_browser_too=True)
print(text)

import sayTHIS as st
st.sayTHIS(text)

import ClipboardTEXT as ctxt
ctxt.clipboard()


import ClipboardCHANGES as cchanges
cchanges.ClipboardCHANGES()
"""

import ClipboardChangesREAD as clipread
clipread.ClipboardChangesREAD()
