import REMINDERS as r
r.remindersON() #reminders checks every minute
