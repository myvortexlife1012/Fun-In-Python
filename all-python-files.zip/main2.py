import mymodule
mymodule.greeting("Mike")


#-----------------------------


#a.pdnaBankGallery3()
#a.seeBirthchartSigns() # as text
#a.guiPhotoGalleryShow()

"""
# pyswisseph, flatlib ... flatlib-0.2.3 pyswisseph-2.8.0.post1
# Set datetime and position
from flatlib.datetime import Datetime
from flatlib.geopos import GeoPos
from flatlib import const
date = Datetime('2022/02/27', '12:00', '+00:00')
pos = GeoPos('33n28', '112w10')

# Finally create the chart
from flatlib.chart import Chart
#chart = Chart(date, pos)

# Build a chart including modern planets
chart = Chart(date, pos, IDs=const.LIST_OBJECTS)

#sun = chart.getObject(const.SUN)

print(f"chart:")
for obj in chart.objects:
    print(obj)

chiron = chart.getFixedStar(const.STAR_)
"""





#print("")
#aa.theFinanceParallels("g","h") # helio Parallel - orb is .3, Geo Parallel is 1.2 - FYI
#print("")
#aa.theFinanceParallels("h","h")



#do a self - with financials



# Re-Number - the array lists
#aa.parse3wordsReNumber(start_with_num=224)



"""
me = aa.me()
#print(f"me ({len(me)}): {me}")
print("Self - ME - Magi Numbers - Calibration:")
powers4 = aa.csvSelfMagiAspects264_3(me, type="self", showLines=False)  # set up with passing vars
print(f"powers4: {powers4}")
"""



#planets360 = aa.cache1Birthchart(y=1981, m=10, d=12, h=9, m1=6, timezone=-6, city="Kansas City, MO")
#does the cache1 trigger 2 csv saves?

#print(f"planets360 ({len(planets360)}): {planets360}")





"""
import ASTROLOGYfunctions as aa
print("Self - ME - Magi Numbers - Calibration:")
powers4 = aa.csvSelfMagiAspects264_3(me, type="self", showLines=False)  # set up with passing vars
print(f"powers4: {powers4}")
"""




#-------------------------------------
#make it easier to loop through the aspects - so other things are more readable

#make a few smaller functions to make it more readable ****
#-------------------------------------





#me = aa.me()
#f.print2(me['planets']['360'])




import ASTROLOGYfunctions as aa
#today = aa.today()
#print(f"today: {len(today)}")
#f.print2(today)


#person2 = aa.person2()
#print(f"person2 ({len(person2)})")
#f.print2(person2)
#print(f"person2 ({len(person2)})")

#make this into a function - pass 2 people in
#aa.csvSYNASTRYMagiAspects264_1()

#calibrating to Miriam - Synastry


#do a person version of this:
#aa.oneSETofData()



#me = aa.me()
#powers4 = aa.csvSelfMagiAspects264_3(me, type="self", showLines=True, showOnlyMatches=True)  # set up with passing vars
#print(f"powers4: {powers4}")



#person = aa.person()
#person2 = aa.person2()
#person3 = aa.person3()
"""
me = aa.me()

print(f"me: {len(me)}")
f.print2(me)
print(f"me: {len(me)}")
"""



"""
print("LOVE SHOULD NOT BE BLANK:")
print("Self - ME - Magi Numbers - Calibration:")
powers4 = aa.csvSelfMagiAspects264_3(me)  # set up with passing vars
print(f"powers4: {powers4}")
# troubleshoot - love should not be blank
#
# there is some problem - I think - with Love - in SELF - power is not adding - perhaps
"""




#get the self one to work like this

#aa.oneSETofData_2people()
#connect it - to the 4words output - so I can see the magi numbers for them
#create the function so I can easily pass the people to the function


# taking a break - following all links - and finding a string in the pages
# need: s136199s.se1


"""
linksString: ['LICENSE.TXT' , 'archive/' , 'archive_gzip/' , 'archive_zip/' , 'ast0/' , 'ast1/' , 'ast2/' , 'ast3/' , 'ast4/' , 'ast5/' , 'ast6/' , 'ast7/' , 'ast8/' , 'ast9/' , 'ast10/' , 'ast11/' , 'ast12/' , 'ast13/' , 'ast14/' , 'ast15/' , 'ast16/' , 'ast17/' , 'ast18/' , 'ast19/' , 'ast20/' , 'ast21/' , 'ast22/' , 'ast23/' , 'ast24/' , 'ast25/' , 'ast26/' , 'ast27/' , 'ast28/' , 'ast29/' , 'ast30/' , 'ast31/' , 'ast32/' , 'ast33/' , 'ast34/' , 'ast35/' , 'ast36/' , 'ast37/' , 'ast38/' , 'ast39/' , 'ast40/' , 'ast41/' , 'ast42/' , 'ast43/' , 'ast44/' , 'ast45/' , 'ast46/' , 'ast47/' , 'ast48/' , 'ast49/' , 'ast50/' , 'ast51/' , 'ast52/' , 'ast53/' , 'ast54/' , 'ast55/' , 'ast56/' , 'ast57/' , 'ast58/' , 'ast59/' , 'ast60/' , 'ast61/' , 'ast62/' , 'ast63/' , 'ast64/' , 'ast65/' , 'ast66/' , 'ast67/' , 'ast68/' , 'ast69/' , 'ast70/' , 'ast71/' , 'ast72/' , 'ast73/' , 'ast74/' , 'ast75/' , 'ast76/' , 'ast77/' , 'ast78/' , 'ast79/' , 'ast80/' , 'ast81/' , 'ast82/' , 'ast83/' , 'ast84/' , 'ast85/' , 'ast86/' , 'ast87/' , 'ast88/' , 'ast89/' , 'ast90/' , 'ast91/' , 'ast92/' , 'ast93/' , 'ast94/' , 'ast95/' , 'ast96/' , 'ast97/' , 'ast98/' , 'ast99/' , 'ast100/' , 'ast101/' , 'ast102/' , 'ast103/' , 'ast104/' , 'ast105/' , 'ast106/' , 'ast107/' , 'ast108/' , 'ast109/' , 'ast110/' , 'ast111/' , 'ast112/' , 'ast113/' , 'ast114/' , 'ast115/' , 'ast116/' , 'ast117/' , 'ast118/' , 'ast119/' , 'ast120/' , 'ast121/' , 'ast122/' , 'ast123/' , 'ast124/' , 'ast125/' , 'ast126/' , 'ast127/' , 'ast128/' , 'ast129/' , 'ast130/' , 'ast131/' , 'ast132/' , 'ast133/' , 'ast134/' , 'ast135/' , 'ast136/' , 'ast137/' , 'ast138/' , 'ast139/' , 'ast140/' , 'ast141/' , 'ast142/' , 'ast143/' , 'ast144/' , 'ast145/' , 'ast146/' , 'ast147/' , 'ast148/' , 'ast149/' , 'ast150/' , 'ast151/' , 'ast152/' , 'ast153/' , 'ast154/' , 'ast155/' , 'ast156/' , 'ast157/' , 'ast158/' , 'ast159/' , 'ast160/' , 'ast161/' , 'ast162/' , 'ast163/' , 'ast164/' , 'ast165/' , 'ast166/' , 'ast167/' , 'ast168/' , 'ast169/' , 'ast170/' , 'ast171/' , 'ast172/' , 'ast173/' , 'ast174/' , 'ast175/' , 'ast176/' , 'ast177/' , 'ast178/' , 'ast179/' , 'ast180/' , 'ast181/' , 'ast182/' , 'ast183/' , 'ast184/' , 'ast185/' , 'ast186/' , 'ast187/' , 'ast188/' , 'ast189/' , 'ast190/' , 'ast191/' , 'ast192/' , 'ast193/' , 'ast194/' , 'ast195/' , 'ast196/' , 'ast197/' , 'ast198/' , 'ast199/' , 'ast200/' , 'ast201/' , 'ast202/' , 'ast203/' , 'ast204/' , 'ast205/' , 'ast206/' , 'ast207/' , 'ast208/' , 'ast209/' , 'ast210/' , 'ast211/' , 'ast212/' , 'ast213/' , 'ast214/' , 'ast215/' , 'ast216/' , 'ast217/' , 'ast218/' , 'ast219/' , 'ast220/' , 'ast221/' , 'ast222/' , 'ast223/' , 'ast224/' , 'ast225/' , 'ast226/' , 'ast227/' , 'ast228/' , 'ast229/' , 'ast230/' , 'ast231/' , 'ast232/' , 'ast233/' , 'ast234/' , 'ast235/' , 'ast236/' , 'ast237/' , 'ast238/' , 'ast239/' , 'ast240/' , 'ast241/' , 'ast242/' , 'ast243/' , 'ast244/' , 'ast245/' , 'ast246/' , 'ast247/' , 'ast248/' , 'ast249/' , 'ast250/' , 'ast251/' , 'ast252/' , 'ast253/' , 'ast254/' , 'ast255/' , 'ast256/' , 'ast257/' , 'ast258/' , 'ast259/' , 'ast260/' , 'ast261/' , 'ast262/' , 'ast263/' , 'ast264/' , 'ast265/' , 'ast266/' , 'ast267/' , 'ast268/' , 'ast269/' , 'ast270/' , 'ast271/' , 'ast272/' , 'ast273/' , 'ast274/' , 'ast275/' , 'ast276/' , 'ast277/' , 'ast278/' , 'ast279/' , 'ast280/' , 'ast281/' , 'ast282/' , 'ast283/' , 'ast284/' , 'ast285/' , 'ast286/' , 'ast287/' , 'ast288/' , 'ast289/' , 'ast290/' , 'ast291/' , 'ast292/' , 'ast293/' , 'ast294/' , 'ast295/' , 'ast296/' , 'ast297/' , 'ast298/' , 'ast299/' , 'ast300/' , 'ast301/' , 'ast302/' , 'ast303/' , 'ast304/' , 'ast305/' , 'ast306/' , 'ast307/' , 'ast308/' , 'ast309/' , 'ast310/' , 'ast311/' , 'ast312/' , 'ast313/' , 'ast314/' , 'ast315/' , 'ast316/' , 'ast317/' , 'ast318/' , 'ast319/' , 'ast320/' , 'ast321/' , 'ast322/' , 'ast323/' , 'ast324/' , 'ast325/' , 'ast326/' , 'ast327/' , 'ast328/' , 'ast329/' , 'ast330/' , 'ast331/' , 'ast332/' , 'ast333/' , 'ast334/' , 'ast335/' , 'ast336/' , 'ast337/' , 'ast338/' , 'ast339/' , 'ast340/' , 'ast341/' , 'ast342/' , 'ast343/' , 'ast344/' , 'ast345/' , 'ast346/' , 'ast347/' , 'ast348/' , 'ast349/' , 'ast350/' , 'ast351/' , 'ast352/' , 'ast353/' , 'ast354/' , 'ast355/' , 'ast356/' , 'ast357/' , 'ast358/' , 'ast359/' , 'ast360/' , 'ast361/' , 'ast362/' , 'ast363/' , 'ast364/' , 'ast365/' , 'ast366/' , 'ast367/' , 'ast368/' , 'ast369/' , 'ast370/' , 'ast371/' , 'ast372/' , 'ast373/' , 'ast374/' , 'ast375/' , 'ast376/' , 'ast377/' , 'ast378/' , 'ast379/' , 'ast380/' , 'ast381/' , 'ast382/' , 'ast383/' , 'ast384/' , 'ast385/' , 'ast386/' , 'ast387/' , 'ast388/' , 'ast389/' , 'ast390/' , 'ast391/' , 'ast392/' , 'ast393/' , 'ast394/' , 'ast395/' , 'ast396/' , 'ast397/' , 'ast398/' , 'ast399/' , 'ast400/' , 'ast401/' , 'ast402/' , 'ast403/' , 'ast404/' , 'ast405/' , 'ast406/' , 'ast407/' , 'ast408/' , 'ast409/' , 'ast410/' , 'ast411/' , 'ast412/' , 'ast413/' , 'ast414/' , 'ast415/' , 'ast416/' , 'ast417/' , 'ast418/' , 'ast419/' , 'ast420/' , 'ast421/' , 'ast422/' , 'ast423/' , 'ast424/' , 'ast425/' , 'ast426/' , 'ast427/' , 'ast428/' , 'ast429/' , 'ast430/' , 'ast431/' , 'ast432/' , 'ast433/' , 'ast434/' , 'ast435/' , 'ast436/' , 'ast437/' , 'ast438/' , 'ast439/' , 'ast440/' , 'ast441/' , 'ast442/' , 'ast443/' , 'ast444/' , 'ast445/' , 'ast446/' , 'ast447/' , 'ast448/' , 'ast449/' , 'ast450/' , 'ast451/' , 'ast452/' , 'ast453/' , 'ast454/' , 'ast455/' , 'ast456/' , 'ast457/' , 'ast458/' , 'ast459/' , 'ast460/' , 'ast461/' , 'ast462/' , 'ast463/' , 'ast464/' , 'ast465/' , 'ast466/' , 'ast467/' , 'ast468/' , 'ast469/' , 'ast470/' , 'ast471/' , 'ast472/' , 'ast473/' , 'ast474/' , 'ast475/' , 'ast476/' , 'ast477/' , 'ast478/' , 'ast479/' , 'ast480/' , 'ast481/' , 'ast482/' , 'ast483/' , 'ast484/' , 'ast485/' , 'ast486/' , 'ast487/' , 'ast488/' , 'ast489/' , 'ast490/' , 'ast491/' , 'ast492/' , 'ast493/' , 'ast494/' , 'ast495/' , 'ast496/' , 'ast497/' , 'ast498/' , 'ast499/' , 'ast500/' , 'ast501/' , 'ast502/' , 'ast503/' , 'ast504/' , 'ast505/' , 'ast506/' , 'ast507/' , 'ast508/' , 'ast509/' , 'ast510/' , 'ast511/' , 'ast512/' , 'ast513/' , 'ast514/' , 'ast515/' , 'ast516/' , 'ast517/' , 'ast518/' , 'ast519/' , 'ast520/' , 'ast521/' , 'ast522/' , 'ast523/' , 'ast524/' , 'ast525/' , 'ast526/' , 'ast527/' , 'ast528/' , 'ast529/' , 'ast530/' , 'ast531/' , 'ast532/' , 'ast533/' , 'ast534/' , 'ast535/' , 'ast536/' , 'ast537/' , 'ast538/' , 'ast539/' , 'ast540/' , 'ast541/' , 'ast542/' , 'ast543/' , 'ast544/' , 'ast545/' , 'ast546/' , 'ast547/' , 'ast548/' , 'ast549/' , 'ast550/' , 'ast551/' , 'ast552/' , 'ast553/' , 'ast554/' , 'ast555/' , 'ast556/' , 'ast557/' , 'ast558/' , 'ast559/' , 'ast560/' , 'ast561/' , 'ast562/' , 'ast563/' , 'ast564/' , 'ast565/' , 'ast566/' , 'ast567/' , 'ast568/' , 'ast569/' , 'ast570/' , 'ast571/' , 'ast572/' , 'ast573/' , 'ast574/' , 'ast575/' , 'ast576/' , 'ast577/' , 'ast578/' , 'ast579/' , 'ast580/' , 'ast581/' , 'ast582/' , 'ast583/' , 'ast584/' , 'ast585/' , 'ast586/' , 'ast587/' , 'ast588/' , 'ast589/' , 'ast590/' , 'ast591/' , 'ast592/' , 'ast593/' , 'ast594/' , 'ast595/' , 'ast596/' , 'ast597/' , 'ast598/' , 'ast599/' , 'ast600/' , 'ast601/' , 'ast602/' , 'ast603/' , 'ast604/' , 'ast605/' , 'ast606/' , 'ast607/' , 'ast999/' , 'fixstars.cat' , 'jplfiles/' , 'longfiles/' , 'md5sum.txt' , 'sat/']
baseUrl = "http://www.astro.com/ftp/swisseph/ephe/"

#if it has a '/' in it - it's another page

"""


#now test it with Miriam's compatibility - generate the similar result




#aa.csv_TODAY_MagiAspects264() # TODAY






#aa.csvSelfMagiAspects264_2() # MYSELF - SELF

# have both charts in the cached csv
# replace sun in magi angles for Earth, or remove them?




#matched, notMatched = aa.whatAspects(me) #returns a list of aspects found in my chart - synastry to my self
#f.print4(matched,"matched")
#f.print3(notMatched,"notMatched")

#person = aa.person()


#import FUNCTIONS as f
#numTimesFound = f.isStringFound(content="1-2-3-4", findMe='4')



#------------------------
#how many magi entries are there for "Jupiter-Quincunx-Chiron"
#magiTitleGroups = aa.whatMagi(matched)
# the 2 indexes available: ['word3'] ... ['magiTitleString']

# the title groups are in different sets - not straight thru

#print(f"magiTitleGroups ({len(magiTitleGroups)}): {magiTitleGroups}")
#f.print2(magiTitleGroups)
#print(f"magiTitleGroups ({len(magiTitleGroups)})")


#------------------------

#i made the output of the data into dict form, so it's all labeled
# now within the matches
# search and log all magi aspects titles/info - that go with the matched
# they will be connected as the linkageName 3 words will be the first entry of both
# then within that will be a {dict} with how many (1-3) entries there were found in the Magi Angles



# not done
# magi = aa.magiAspects(me) #returns a list of 3names



#print(f"me: ({len(me)}):")
#f.print2(me)
#print(f"me: ({len(me)}):")

#print(f"person: ({len(person)}):")
#f.print2(person)
#print(f"person: ({len(person)}):")



#import ASTROLOGYfunctions as aa
#justThePlanet = aa.keepBeforeLineChar(string="Pluto|genders:manwoman")
#print(f"justThePlanet: {justThePlanet}")





# try to find the multiplier - in the php cosmic array





"""
import ASTROLOGYfunctions as aa
planetName = "Sun"
totalLinkagesForPlanet, rows = aa.linkagesByPlanet(planet=planetName)
print(f"TOTAL LINKAGES: {totalLinkagesForPlanet} # linkages for {planetName} ... rows ({len(rows)})")
"""



#import ASTROLOGYfunctions as aa
#aa.loopingThruTheLinkages3()

# add genders, names, and - on the saveLinkage output - write that info in there
# so I can understand who's planets are being used






#aa.oneSETofData()







# cosmic_reports_6reports_1function_text_output.php



#aa.oneSETofData()

#gather all planet names - to make sure I have them all loaded up
#import ASTROLOGYmagi as a
#specialAspects = a.magiAspects()




#i'm only checking from person Left as person1 - and person Right as Person 2
# but now I realize that I have to do both sides - I have to see if the other side matches
#it was always Michael to Miriam, Planet Angle Planet
#it could go the other way too - just do what I'm doing but flip flop it also - if it's easy
#half way there - it seems
# test the linkages - the other way as well









#the power is added - the check for linkage is added and working
# I need to access the title - and scan for Luck, Love, Sex or Drama - and update their 4 power vars
# -since the power is there - now I need to save the power- in the right, Luck, Love, Sex, Drama categories





# find the aspects loop - and run it - adding the power each time it finds a match






#-----------------------------


#import ASTROLOGYfunctions as aa #y=1989, m=07, d=11, h=11, m1=27
#aa.cache1Birthchart(y=1989, m=7, d=11, h=11, m1=27, timezone=-5, city="Phoenix, AZ")

#--------NOTE-----------
#the geo location services - for timezone - and lat long - don't like 3 words in the city
#city, state ... or state, country
# bad: Calgary, Alberta, Canada ... change it to Alberta, Canada


#import ASTROLOGYfunctions as aa
#aa.cache1Birthchart(y=1981, m=2, d=22, h=3, m1=30, timezone=-5, city="Kankakee, IL")

#timeZoneOffset2 = aa.getTimezoneOffsetBing(city="Kankakee, IL", datetime="22.02.1981 3:30:00")
#print(f"timeZoneOffset2: {timeZoneOffset2}")


#import ASTROLOGYfunctions as aa
#timeZoneOffset1 = aa.getTimezoneOffsetBing(city="Kansas City, MO", datetime="10.12.1981 3:15:00")
#print(f"timeZoneOffset1: {timeZoneOffset1}")





#---------------
# NOTE: WHENEVER I ADD NEW ASTROIDS - I HAVE TO RERUN THIS FUNCTION - TO ADD THE NEW ONES IN
#----------------
#runs through everyone in my pdnabank and caches their birthchart as csv - using swetest
#import ASTROLOGYfunctions as aa
#aa.cacheAllBirthcharts()





#import ASTROLOGYfunctions as aa


#connect where it says (of person 2)
#connect where it says (of person 1) ... to the planet 360deg number - of 'that person'




# aa.savingSettingPowerNumber(): #practice







#import ASTROLOGYfunctions as aa
#aa.cacheAllBirthcharts()



# Finish adding:
#NorthNode: 111 -- mean node/true node - already have -- SouthNode is 180 degrees from that
#SouthNode: 222 # cache1Birthchart()
#-- add speed - re-cache birthcharts, save houses too




# A "Date" Guarantee - good marketing

#--------------------------------------

#import OPENsomething as o
#csv = o.loadCachedCSVbirthchart(y=1981,m=10,d=12,h=3,m1=6,lat="39n05",long="94w34")
#print(f"\n\ncsv ({len(csv)}): {csv}\n")



#import OPENsomething as o
#o.cachedAllMiniBirthchartCSVs()


#import OPENsomething as o
#planets1 = o.openSaveBirthchartCSVcache(y=1981,m=10,d=12,h=3,m1=6,lat="39n05",long="94w34")
#print(f"planets1 ({len(planets1)}): {planets1}")

#planets2 = o.openSaveBirthchartCSVcache(y=1984,m=4,d=18,h=12,m1=0,lat="19N25",long="99W7")
#print(f"planets2 ({len(planets2)}): {planets2}")




# import FUNCTIONS as f
# degrees360 = f.sign60to360(sign="Libra",sign60=18)
# import FUNCTIONS as f
# sign,sign60 = f.sign360to60(deg360=198)






#now finish Caching all the birthcharts

#I did this:
#import OPENsomething as o
#o.cacheAllBirthchartHTMLs()
#o.cachedAllMiniBirthchartCSVs()


#---------------------------------

#mycosmicdna in python
# drift together
# drift the new dating site - buyable: drift.date

#import GuiAPPs as a
#a.seeBirthchartSigns()


#-----------------------------



# https://serennu.com/astrology/ephemeris.php




#Save the page as the keys that make it unique - filename
#Parse this with BeautifulSoup

#https://serennu.com/astrology/ephemeris.php?inday=12&inmonth=10&inyear=1981&inhours=03&inmins=06&insecs=00&insort=pname&z=t&gh=g&addobj=3%2C+2060&inla=39n05&inlo=94w34&h=P
import requests
"""
# Define a variable to contain a web page URL.
filename = "1981-10-12--03-06--39n05-94w34.html"
web_page_url = "https://serennu.com/astrology/ephemeris.php?inday=12&inmonth=10&inyear=1981&inhours=03&inmins=06&insecs=00&insort=pname&z=t&gh=g&addobj=3%2C+2060&inla=39n05&inlo=94w34&h=P"
"""



"""
pyswisseph

3, 2060
3 Juno
2060 Chiron

what is the lat long for Kansas City, MO
: 39°05'59"N 94°34'42"W
39n05
94w34
"""







#import ImageSAVER as s
#s.createThumbsForPdnaBank()

#import listAllFILES as f
#f.getAfewImagesPdnaBank()


#import GuiAPPs as a
#a.pdnaBankSHOWMyPeople() # photo gallery layout

#not finished - can I get the birthcharts in here - and build the basic square for each
#import GuiAPPs as a
#a.pdnaBankGallery3() #maybe it starts at a later number - and it is dynamic
#it starts at 24-47 - and it's easy to change the 'startingNumber'
#total/24 - pages there are ... 140/24 ... 6 pages




"""
#still working on this - once I get the thumbnails created
#
import GuiAPPs as a
import OPENsomething as o
people = o.pdnaBankGetMyPeople() #--GETS ALL PEOPLE from PDNABANK--
#working on this
#generate smaller thumbnails - 50x50 maybe
#take the layout - to accomodate small thumbnails and their name
#it's a start
# import GuiAPPs as a
a.pdnaBankSHOWMyPeople(people) # photo gallery layout
"""



#------------------------------------------





# --- get a set of these on one board
#import PlotGRAPHS as p
#p.doublePlot3()

#import PlotGRAPHS as p
#p.doublePlot8()




#show 4 on one board
#import PlotGRAPHS as p
#p.showNiceCryptoView("SHIB-USD")


#p.showCrypto("ETH-USD",days=90)
#p.showCrypto("BTC-USD",days=30)
#p.showCrypto("BTC-USD")
#put it in a gui, where it updates the image - and advances it - giving it one more plot point every second





#prices = dateprices[:60] #get just 2 months of data
#prices = dateprices[:30] #get just 1 month of data


# dateprices: [(0, 3141.69), (1, 3164.24), (2, 3043.41), (3, 3322.21), (4, 3265.44), (5, 3310.5), (6, 3156.5), (7, 3014.84), (8, 3020.08), (9, 3182.7), (10, 3286.93), (11, 3226.08), (12, 3242.11), (13, 3319.25), (14, 3172.45), (15, 3224.91), (16, 3100.32), (17, 3270.6), (18, 3244.4), (19, 3227.0), (20, 3224.37), (21, 3433.73), (22, 3834.82), (23, 3790.98), (24, 3940.61), (25, 3887.82), (26, 3952.13), (27, 3928.37), (28, 3426.39), (29, 3497.31), (30, 3427.34), (31, 3211.5), (32, 3270.27), (33, 3410.13), (34, 3285.51), (35, 3429.16), (36, 3615.28), (37, 3571.29), (38, 3398.53), (39, 3432.01), (40, 3329.44), (41, 2958.99), (42, 2764.43), (43, 3077.86), (44, 3155.52), (45, 2931.66), (46, 2925.56), (47, 3062.26), (48, 2934.13), (49, 2807.29), (50, 2853.14), (51, 3001.67), (52, 3307.51), (53, 3391.69), (54, 3418.35), (55, 3380.08), (56, 3518.51), (57, 3580.56), (58, 3587.97), (59, 3563.75), (60, 3575.71), (61, 3425.85), (62, 3545.35), (63, 3492.57), (64, 3606.2), (65, 3786.01), (66, 3862.63), (67, 3830.38), (68, 3847.1), (69, 3748.76), (70, 3877.65), (71, 4155.99), (72, 4054.32), (73, 3970.18), (74, 4171.66), (75, 4087.9), (76, 4217.87), (77, 4131.1), (78, 3930.25), (79, 4287.31), (80, 4414.74), (81, 4325.65), (82, 4288.07), (83, 4324.62), (84, 4584.79), (85, 4607.19), (86, 4537.32), (87, 4486.24), (88, 4521.58), (89, 4620.55), (90, 4812.08), (91, 4735.06), (92, 4636.17), (93, 4730.38), (94, 4667.11), (95, 4651.46), (96, 4626.35), (97, 4557.5), (98, 4216.36), (99, 4287.59), (100, 4000.65), (101, 4298.3), (102, 4409.93), (103, 4269.73), (104, 4088.45), (105, 4340.76), (106, 4239.98), (107, 4274.74), (108, 4030.9), (109, 4096.91), (110, 4294.45), (111, 4445.1), (112, 4631.47), (113, 4586.99), (114, 4511.3), (115, 4220.7), (116, 4119.58), (117, 4198.32), (118, 4358.73), (119, 4315.06), (120, 4439.35), (121, 4119.81), (122, 3908.49), (123, 4084.45), (124, 4134.45), (125, 3784.22), (126, 3745.44), (127, 4018.38), (128, 3962.46), (129, 3879.48), (130, 3960.86), (131, 3922.59), (132, 3933.84), (133, 4020.26), (134, 3982.09), (135, 4108.01), (136, 4047.98), (137, 4093.28), (138, 4067.32), (139, 4037.54), (140, 3800.89), (141, 3628.53), (142, 3713.85), (143, 3682.63), (144, 3769.69), (145, 3829.56), (146, 3761.38), (147, 3794.05), (148, 3550.38), (149, 3418.4), (150, 3193.21), (151, 3091.97), (152, 3157.75), (153, 3083.09), (154, 3238.11), (155, 3372.25), (156, 3248.28), (157, 3310.0), (158, 3330.53), (159, 3350.92), (160, 3212.3), (161, 3164.02), (162, 3095.82), (163, 3001.12), (164, 2557.93), (165, 2405.18), (166, 2535.03), (167, 2440.35), (168, 2455.93), (169, 2468.03), (170, 2423.0), (171, 2547.09), (172, 2597.08), (173, 2603.46), (174, 2688.27), (175, 2792.11), (176, 2682.85), (177, 2679.16), (178, 2983.58), (179, 3014.64), (180, 3057.47), (181, 3142.47), (182, 3122.6)]

# dateprices: [(20210810, 3141.69), (20210811, 3164.24), (20210812, 3043.41), (20210813, 3322.21), (20210814, 3265.44), (20210815, 3310.5), (20210816, 3156.5), (20210817, 3014.84), (20210818, 3020.08), (20210819, 3182.7), (20210820, 3286.93), (20210821, 3226.08), (20210822, 3242.11), (20210823, 3319.25), (20210824, 3172.45), (20210825, 3224.91), (20210826, 3100.32), (20210827, 3270.6), (20210828, 3244.4), (20210829, 3227.0), (20210830, 3224.37), (20210831, 3433.73), (20210901, 3834.82)]




#save different data:
#import CRYPTO as c
#c.downloadCryptoCSV2b(crypto="SHIB-USD")
#import CRYPTO as c
#c.downloadCryptoCSV2c(crypto="ETH-USD")

#SHOW IN THIS ORDER:
#import PlotGRAPHS as p
#p.plotCSVcryptoMatplot1(crypto="ETH-USD") #load other csv files
#p.plotCSVcryptoMatplot2(crypto="ETH-USD", plotQty=30) #load other csv files
#p.plotCSVcryptoMatplot3(crypto="ETH-USD")
#p.plotCSVcryptoMatplot2(crypto="SHIB-USD",days=14)
# p.plotCSVcryptoMatplot(crypto="ETH-USD")



#simulate a crypto price graph of live tick data

#--games to make---:
# Ping Pong
# Volley Ball
# Hand Ball
# games where you're chasing something
#------------------


# set it up as a layout
#import CRYPTO as c
#c.cryptoStartup()






#import PlotGRAPHS as p
#p.plotCSVcryptoMatplot(crypto="SHIB-USD")
#p.plotCSVcryptoMatplot(crypto="ETH-USD")
#p.plotCSVcryptoMatplot(crypto="ADA-USD")
#p.plotCSVcryptoMatplot(crypto="BTC-USD")
#--------------
#p.plotCSVcrypto1matplotlibShow() # candlesticks
#plot.crytpoPlot1matplotlibShow() #see 7 graphs of 7 cryptos


#1st step seeing the current value of cryptos

#then a 7 day High
#then a 7 day Low

#then how much of a percentage move from current price - for high,low




#import CRYPTO as c
#c.downloadCryptoCSV2(crypto="BTC-USD")
#c.downloadCryptoCSV2(crypto="ETH-USD")
#c.downloadCryptoCSV1(crypto="ETH-USD")

"""
import yfinance as yf
msft = yf.Ticker("MSFT")
# get stock info
print(msft.info)
# get historical market data
hist = msft.history(period="5d")
print(f"hist: {hist}")
print(f"hist['Close']: {hist['Close']}")

import matplotlib.pyplot as plt
import seaborn
# Plot everything by leveraging the very powerful matplotlib package
hist['Close'].plot(figsize=(16, 9))
"""






"""
import pandas as pd
import pandas_datareader.data as pdr
import datetime as dt

start = dt.datetime(2020,2,19)
end = dt.datetime(2021,2,18)
df = pdr.DataReader('BTC-USD','yahoo',start,end)
"""





#------------------------------------------










#import GuiGAMES as g
#g.tkinterGame1()

#g.liveCryptoTickerPlot2()
#g.liveCryptoTickerPlot1()

#g.pygame11()
#g.pygame10()
#g.pygame9()
#g.pygame8()
#g.pygame7()
#.pygame6()
#g.pygame5()
#g.pygame4()
#g.pygame3()
#g.pygame2()
#g.pygame1()


"""
x = 100
y = 100
velocity = 0
acceleration = 0.1
while True:
    DISPLAY.fill((255,255,255))
    pygame.draw.rect(DISPLAY, BLUE, (x,y, 50, 50))
    y += velocity
    velocity += acceleration
    pygame.display.update()
    pygame.time.delay(10)
"""
















#file browser tkinter


# The label widget in Python Tkinter is used to display text and images on the application window.

# canvas - tkinter


#do the photo gallery thing?
#using the thumbnail images - do a reverse list - just for those


#import GuiAPPs as a
#a.photoGallery1() # photo gallery layout




#import GuiAPPs as guiApps
#guiApps.guiBGchangeShow()



#import BackgroundCHOOSE as b
#filename = r"z-IMAGES_1\0.cool\!new1\video_background\clouds_during_golden_hour.jpg"
#filename = r"C:\Users\myvor\PycharmProjects\pythonProject\unsplash_green.jpg" #full file location
#filename = r"z-IMAGES_1\0.cool\!new1\beach_palm_trees\aerial_photography_of_camper_truck_on_shore_near_coconut_trees.jpg" #full file location
#b.setDesktopBackground(filename)





#import GuiAPPs as guiApps
#guiApps.guiBGchangeShow()


"""
import listAllFILES as filelist
folder_path = "z-IMAGES_1/0.cool/"
files = filelist.listAllImages(folder_path)
for file in files:
    if "thumbnail" in file:
        print(f"THUMBNAIL: {file}")
    else:
        pass
        #print(f"file: {file}")
"""


# import ImageSAVER as saver
# width, height = saver.imageWidthHeight(filename)








"""
import listAllFILES as filelist
folderPath = "z-IMAGES_1" #"z-IMAGES_1/0.cool/!new1/beach_palm_trees"
print(f"folderPath: {folderPath}")
files = filelist.listAllImages(folderPath)
print(f"only images: ({len(files)})")
print(files)

import ImageSAVER as saver
saver.createThumbsForImageFolder(folderPath)
"""





# image changed every sec, by plot, tk-update image, pysimplegui update image



#import GuiAPPs as apps
#apps.simpleWindow2()
# apps.threeButtons3Pages1Graph()

#

"""
import GuiAPPs as apps
imagePath = 'C:\\Users\\myvor\\Desktop\\Backgrounds\\grass.gif'
apps.openGIF(imagePath)
"""

"""
import GuiAPPs as apps
imagePath = 'C:\\Users\\myvor\\Desktop\\Backgrounds\\will-turner-GTPT_fNFQiE-unsplash.jpg'
apps.openImage2(imagePath,300,500) # w and h
"""




#import GuiAPPs as apps
#apps.fileListWithOpen2()
#apps.fileListWithOpen1()






#import GuiAPPs as apps
#apps.wholeImageIsAButton()



#import GuiAPPs as apps
#apps.photoWithCaption()













#import ImageSAVER as saver
#saver.createThumbsForImageFolder(folderPath = "z-IMAGES_1") # "z-IMAGES_1/0.cool/!new1/beach_palm_trees"
#folderPath="C:\\Users\\myvor\\Desktop\\Backgrounds\\")
# saver.imageResizeIntoThumbs(imageFilePath="C:\\Users\\myvor\\Desktop\\Backgrounds\\unsplash_green.jpg", width=250, jpgQuality=70)


import ImageSAVER as saver
# imageFilePath="C:\\Users\\myvor\\Desktop\\Backgrounds\\unsplash_green.jpg"
# saver.createThumbsForImageFolder(folderPath = "z-IMAGES_1/0.cool/!new1/beach_palm_trees")


#import GuiAPPs as apps  # buttons that do things
#apps.basicCanvasDrawing4() # 6 images with Filenames # a photo gallery layout

# apps.basicCanvasDrawing1() # LEARNING - tkinter canvas - drawing




"""
import GuiAPPs as apps
#imagePath = 'C:\\Users\\myvor\\Desktop\\Backgrounds\\png.png'
#imagePath = 'C:\\Users\\myvor\\Desktop\\Backgrounds\\grass.gif'
imagePath = 'C:\\Users\\myvor\\Desktop\\Backgrounds\\will-turner-GTPT_fNFQiE-unsplash.jpg'
apps.openImage4Canvas(imagePath,500,500) # w and h
"""





"""
import GuiAPPs as apps
imagePath = 'C:\\Users\\myvor\\Desktop\\Backgrounds\\will-turner-GTPT_fNFQiE-unsplash.jpg'
apps.openImage(imagePath)
"""


#matplotlib
# what is:
# Subplots mean groups of axes that can exist in a single matplotlib figure.
# the Figure, which contains all the plot elements, matplotlib.figure.Figure() class






#import PlotGRAPHS as plot
#plot.plotPointsTkinter() # matplotlib # blue dots - and red color x's




"""
import matplotlib.pyplot as plt
point1 = [1, 2]
point2 = [3, 4]
x_values = [point1[0], point2[0]] #gather x-values
y_values = [point1[1], point2[1]] #gather y-values
plt.plot(x_values, y_values)
plt.savefig("plot.png")
"""

"""
import matplotlib.pyplot as plt
w = 4
h = 3
d = 70
plt.figure(figsize=(w, h), dpi=d)
x = [1, 2, 4]
y = [2, 4, 4.5]

plt.plot(x, y)
plt.savefig("out.png")
"""




#list text - down in pysimplegui


# import GuiAPPs as apps
# apps.fileListGui()

#populate it with a photo folder



#------------------------------------




"""
#saves settings

def Everything():
    import PySimpleGUI as sg
    sg.ChangeLookAndFeel('TanBlue')

    column1 = [
        [sg.Text('Column 1', background_color=sg.DEFAULT_BACKGROUND_COLOR, justification='center', size=(10, 1))],
        [sg.Spin(values=('Spin Box 1', '2', '3'), initial_value='Spin Box 1', key='spin1')],
        [sg.Spin(values=('Spin Box 1', '2', '3'), initial_value='Spin Box 2', key='spin2')],
        [sg.Spin(values=('Spin Box 1', '2', '3'), initial_value='Spin Box 3', key='spin3')]]

    layout = [
        [sg.Text('All graphic widgets in one form!', size=(30, 1), font=("Helvetica", 25))],
        [sg.Text('Here is some text.... and a place to enter text')],
        [sg.InputText('This is my text', key='in1', do_not_clear=True)],
        [sg.Checkbox('Checkbox', key='cb1'), sg.Checkbox('My second checkbox!', key='cb2', default=True)],
        [sg.Radio('My first Radio!     ', "RADIO1", key='rad1', default=True),
         sg.Radio('My second Radio!', "RADIO1", key='rad2')],
        [sg.Multiline(default_text='This is the default Text should you decide not to type anything', size=(35, 3),
                      key='multi1', do_not_clear=True),
         sg.Multiline(default_text='A second multi-line', size=(35, 3), key='multi2', do_not_clear=True)],
        [sg.InputCombo(('Combobox 1', 'Combobox 2'), key='combo', size=(20, 1)),
         sg.Slider(range=(1, 100), orientation='h', size=(34, 20), key='slide1', default_value=85)],
        [sg.InputOptionMenu(('Menu Option 1', 'Menu Option 2', 'Menu Option 3'), key='optionmenu')],
        [sg.Listbox(values=('Listbox 1', 'Listbox 2', 'Listbox 3'), size=(30, 3), key='listbox'),
         sg.Slider(range=(1, 100), orientation='v', size=(5, 20), default_value=25, key='slide2', ),
         sg.Slider(range=(1, 100), orientation='v', size=(5, 20), default_value=75, key='slide3', ),
         sg.Slider(range=(1, 100), orientation='v', size=(5, 20), default_value=10, key='slide4'),
         sg.Column(column1, background_color='gray34')],
        [sg.Text('_' * 80)],
        [sg.Text('Choose A Folder', size=(35, 1))],
        [sg.Text('Your Folder', size=(15, 1), auto_size_text=False, justification='right'),
         sg.InputText('Default Folder', key='folder', do_not_clear=True), sg.FolderBrowse()],
        [sg.Button('Exit'),
         sg.Text(' ' * 40), sg.Button('SaveSettings'), sg.Button('LoadSettings')]
    ]

    window = sg.Window('Form Fill Demonstration', default_element_size=(40, 1), grab_anywhere=False)
    # button, values = window.LayoutAndRead(layout, non_blocking=True)
    window.Layout(layout)

    while True:
        event, values = window.Read()

        if event == 'SaveSettings':
            filename = sg.PopupGetFile('Save Settings', save_as=True, no_window=True)
            window.SaveToDisk(filename)
            # save(values)
        elif event == 'LoadSettings':
            filename = sg.PopupGetFile('Load Settings', no_window=True)
            window.LoadFromDisk(filename)
            # load(form)
        elif event in ('Exit', None):
            break

    # window.CloseNonBlocking()
Everything()
"""


"""
# Simple Reminder System - Schedule Reminders

import time
time.sleep(5*60) #every 5 minutes, check if it's this time and date:
# set time and date for each reminder
timeAndDate = "2/3/2022 at 3:00 pm"
# set message of reminder
reminderMessage = "This is the reminder message"
# set any other actions that go with reminder

# gui that displays the pop-up window ready
# import GuiAPPs as apps
# apps.note("Hello World")

# email the reminders
# import SendAnEMAIL as email
# email.sendAnEMAIL(message_body,subject1,to_who,from_who)

# 1 file, reminders.txt, put the reminder note storage
# reminder date-time + message + reminder schedule
10/12/2022 at 1:00 pm||Happy Birthday||["7 d", "6 d", "5 d", "4 d", "3 d", "2 d", "1 d", "4 h", "2 h", "1 h", "30 m", "15 m", "0 m"]
2/4/2022 at 11:25 pm||Quick Reminder||["2 h", "1 h", "30 m", "15 m", "0 m"]

"""


"""
import REMINDERS as r
import datetime
nowDatetime1 = datetime.datetime.now()
nowDatetime1 = nowDatetime1.replace(second=0, microsecond=0)  # same minute
datetimeString = str(nowDatetime1)
y, m, d, h, m1, s = r.varsFromDatetimeString(datetimeString)
print("6 datetime vars:")
print(y, m, d, h, m1, s)
"""


#it showed me the 15 min reminder

#import REMINDERS as r
#r.remindersON() #reminders checks every minute


"""
# send an email
to_who = "myvortexlife1012@gmail.com"  # Enter receiver address
from_who = to_who
message = "Brush Your Teeth"
import datetime
nowDatetime1 = datetime.datetime.now()
body = message+"\n\n\n"+str(nowDatetime1)
subject1 = "Reminder to do something - " + message
import SendAnEMAIL as e
e.sendEmail2(body,subject1,to_who,from_who)
#e.sendAnEMAIL(body,subject1,to_who,from_who)
"""




"""
import REMINDERS as reminders

#create a datetime from a future date
y=2022
m=2
d=4
h=18
m1=17
datetime = reminders.createAdateTime(y,m,d,h,m1)
print (f"datetime: {datetime}")
#convert it to the good readable string
datetimeReadable = reminders.notReadableDatetimeToReadable(datetime)
print (f"datetimeReadable: {datetimeReadable}")
#convert that back to a datetime
datetime2 = reminders.readableDatetimeStringToDateTime(datetimeReadable)
print (f"datetime2: {datetime2}")
datetimeReadable2 = reminders.notReadableDatetimeToReadable(datetime2)
print (f"datetimeReadable2: {datetimeReadable2}")
"""

#convert that back to a readable string








#import REMINDERS as reminders
#datetime = reminders.readableDatetimeToNot(datetimeString="10/12/2022 at 2:00 pm") #"2/4/2022 at 12:10 pm"
# 10/12/2022 at 2:00 pm --> 2022-10-12 14:00:00

"""
import FUNCTIONS as fns
dateTimeStr = fns.getTimeAndDateAMPM()
"""



"""
import GuiAPPs as apps
apps.note("Hello World")
"""





"""
import REMINDERS as reminders
date = reminders.createAdateTime(y=2022,m=2,d=3,h=18,m1=00,s=00)
true = fns.has_expired(date)
print(f"true: {true}")
"""






"""
import datetime

date = datetime.date(2022,2,2)

date_of_today = datetime.date.today()

if date == date_of_today:
    print("It is the correct date")
    print(True)
    #check the time now
    #is it at or past the time
else:
    print("It is not the correct date")
    print("Do nothing")
"""




"""
import GuiAPPs as guiApps
title="-- Quick Reminder --"
message=" *** This is what you wanted to be reminded of *** "
guiApps.notificationMESSAGE(title=title, message=message)
#ding sound
"""


#cycle through the frame images
#changing the background each time


#Change the background automatically


"""
import VIDEO as vid
vid.save200FramesFromVideo()
"""


"""
# --------------------------------------------
# DESKTOP WALLPAPER - VIDEO WALLPAPER (simulates)
#
import listAllFILES as lfs
folder_path="z-Frames/beach_with_rocks"
array = lfs.listAllFILES(folder_path)
pics = array[1]
print(str(len(pics))+" pics")

import BackgroundCHOOSE as bkng
while True: #keep playing it on the screen
    bkng.BackgroundSequenceChange(array,speed=.25)# speed is time to sleep between
"""
# --------------------------------------------






"""
import ImageSAVER as saver
saver.unsplashImagesFromSearch(q="wallpaper background",perPage=30) #max is 30 on the API, it seems
saver.unsplashImagesFromSearch(q="moon",perPage=30)
saver.unsplashImagesFromSearch(q="falling star",perPage=30)
saver.unsplashImagesFromSearch(q="nebulas",perPage=30)
"""
#UNSPLASH PROFILE PAGE - photos
#import ImageSAVER as saver
#saver.unsplashPersonsPage("@borisbaldinger")



# import ImageSAVER as saver
# saver.download(imgUrl="http://", savePath="z-IMAGES_1/!new/test_search_query", imgFilename="long_file_name.jpg")



"""
import ImageSAVER as saver
saver.download(
    imgUrl="https://unsplash.com/photos/ZUJ6uPPnTGY/download?ixid=MnwxMjA3fDB8MXxhbGx8fHx8fHx8fHwxNjQzNzQzNzEx&force=true",
    savePath="z-IMAGES_1/!new/test_search_query",
    imgFilename="sunset_mountains_1.jpg"
)
"""



"""
from lxml import html
import os
import random
import requests
import string

unsplash = requests.get("https://unsplash.com/")
html_tree = html.fromstring(unsplash.text)

# Collects picture source as URL
weekly_ten_pictures = html_tree.xpath('/html/body/div/div/div/div/div/a/img/@src')

# Collects the names of the photographers
picture_credits = html_tree.xpath('/html/body/div/div/div/div/div/h2/a[2]/text()')

credits_and_pictures = zip(picture_credits, weekly_ten_pictures)
"""
"""
desktop_unsplash_dir = os.path.expanduser('~/Desktop/unsplash')

# Creates an "unsplash" directory in Desktop if the directory doesn't already exist
if not os.path.exists(desktop_unsplash_dir):
    os.makedirs(desktop_unsplash_dir)
"""
"""
for credit, picture in credits_and_pictures:

    picture_data = requests.get(picture)

    if picture_data.status_code == 200:

        picture_html_tree = html.fromstring(picture_data.text)
        picture_name = ''.join(random.choice(string.hexdigits) for i in range(16))

        file_path = os.path.expanduser('~/Desktop/unsplash/{}-{}.jpeg'.format(credit, picture_name))

        print("Downloading {}-{}.jpeg".format(credit, picture_name))
        with open(file_path, 'wb') as f:
            f.write(picture_data.content)
        print("Finished.\n")
"""


"""
import htmlThumbnails as thumbnails  # in the cool folder-yes
folder0 = "0.cool" #0.cool, 0.cute, 0.food, 0.house, 0.animals
folder_name = "premium_wallpapers_rock_stacks"
thumbnails.makeHTMLforImages2( folder0, folder_name ) #makes the html file for imgs
"""



# make exe for the background change app
# pip install auto-py-to-exe # type 'auto-py-to-exe' in the console ... gui appears


#crypto ticks
#plot it - % it moved up or down - each tick

# import PLOTGraphs as plot
# plot.coolTerminalTextOutput()



#import PlotGRAPHS as plot
#plot.crytpoLivePlot1()
#plot.crytpoPlot1()
#plot.coolGUIOutput3()
#plot.coolGUIOutput4()
#plot.coolTerminalTextOutput()

#import CRYPTO as crypto #saves the tick data
#crypto.getCryptoInfo()

# -------------

# Python Live Plotting Cryptocurrency


#import PlotGRAPHS as plot
#plot.crytpoCandlestickPlot2()
#plot.crytpoCandlestickPlot1()



#import CRYPTO as crypto
#crypto.getCryptoDATA()


#import ANIMATION as animate
#animate.animatedMakeSnowFlakes()



#import AllWINDOWS as wins
#wins.moveWindowsByName() #moves an untitled Notepad2 to the top left of screen
#wins.OpenProgramByStartMenu("firefox")



#import AllWINDOWS as wins
#wins.screenSizeOSheight()




#import AllWINDOWS as wins
#wins.OpenProgramByStartMenu2()



"""
import OPENaFileOrFolder as opn
# filepath = r"C:\\Users\myvor\\Pictures\\0.animals\\beautiful tiger wallpapers\\!image18.jpg"
folderpath = r"C:\\Users\\myvor\\Pictures\\0.animals\\beautiful tiger wallpapers"
# opn.openFileWithDefaultProgram(filepath)
opn.openFileWithDefaultProgram(folderpath)
"""











#import AllWINDOWS as wins
#wins.mousePositionLOOP()





#res = wins.screenSize2() # The screen resolution is: (1536, 864)
#wins.screenSize() # OS Window Size: # Size(width=1920, height=1080)



#df = pd.DataFrame()

#df.plot.line  # noqa: E225, E999 # df.plot.area     df.plot.barh     df.plot.density  df.plot.hist     df.plot.line     df.plot.scatter
# df.plot.bar      df.plot.box      df.plot.hexbin   df.plot.kde      df.plot.pie




#import CRYPTO as crypto #saves the tick data
#crypto.cryptoGetTICKS("BTC-USD") #default is for 'ETH-USD'


# import OpenAFileOrFolder as opn
# filepath = r"C:\Users\myvor\Pictures\0.animals\beautiful tiger wallpapers\!image18.jpg"
# opn.openFileWithDefaultProgram(filepath)



"""
import AllWINDOWS as wins
wins.whereMouseClicks()
"""

"""
import ctypes
window = ctypes.windll.user32.GetForegroundWindow()
print("window:")
print(window)
"""

"""
import AllWINDOWS as wins
windows = wins.arrayOfWindowsVisible()
print(f"windows ({len(windows)}):")
print(windows)
"""


#import GuiAPPs as guiApps
#guiApps.guiBGchangeShow()

# import win32gui
# pip install win32gui



"""
import AllWINDOWS as wins
#needs win32gui - python 3.6 env
windows = wins.arrayOfWindows()
print("windows:")
print(windows)"""


#windows:
# [{'x': 1314, 'y': 120, 'w': 207, 'h': 42, 'name': 'FastStone Capture'},
# {'x': 338, 'y': 151, 'w': 1180, 'h': 656, 'name': 'pythonProject – AllWINDOWS.py'},
# {'x': 376, 'y': 51, 'w': 1103, 'h': 678, 'name': 'New Tab - Brave'},
# {'x': 34, 'y': 78, 'w': 334, 'h': 540, 'name': 'Calculator'},
# {'x': 179, 'y': 179, 'w': 895, 'h': 518, 'name': 'C:\\Windows\\system32\\cmd.exe'},
# {'x': 478, 'y': 73, 'w': 1038, 'h': 712, 'name': 'Settings'},
# {'x': 77, 'y': 77, 'w': 1152, 'h': 598, 'name': 'QTrayIconMessageWindow'},
# {'x': 505, 'y': 190, 'w': 526, 'h': 422, 'name': 'mbamtray'},
# {'x': 26, 'y': 26, 'w': 1152, 'h': 598, 'name': 'QTrayIconMessageWindow'},
# {'x': 128, 'y': 128, 'w': 1152, 'h': 598, 'name': 'MS_WebcheckMonitor'}]


#import GuiAPPs as guiApps
#guiApps.guiBGchangeShow()
# guiApps.GuiWindowLAYOUTSshow()
# guiApps.GuiWithImageBUTTONSshow()


#make an invisible right arrow that changes the background to a similar but different one
"""
import ctypes
from ctypes import wintypes
user32 = ctypes.windll.user32
h_wnd = user32.GetForegroundWindow()
print("h_wnd: ")
print(h_wnd)
pid = wintypes.DWORD()
user32.GetWindowThreadProcessId(h_wnd, ctypes.byref(pid))
print("pid.value: ")
print(pid.value)
"""
# python windows get window dimensions - of active window, of a draggable area - maybe menu area
# python windows mouse drag


#import AllWINDOWS as wins
#wins.moveMouseTO(500,50,"FAST")


"""

import GuiAPPs as guiApps
guiApps.guiBGchangeShow()
# guiApps.GuiWindowLAYOUTSshow()
# guiApps.GuiWithImageBUTTONSshow()
"""

#---------------
# a button that runs this code:
"""
#Change the background automatically
import listAllFILES as lfs
folder_path="z-IMAGES_1/0.cool/premium_wallpapers_rock_stacks" #folder_path="z-IMAGES_1/0.cool"
array = lfs.listAllFILES(folder_path)
length = array[0]
pics = array[1]

#keep it in the same folder of images - so it feels consistent
import BackgroundChooseRANDOM as bgcrand
bgcrand.BackgroundChooseRANDOM(array)
"""



"""
import KeyLOGGER as keyLogger
keyLogger.keyLogger2Start()
"""


import GuiAPPs as guiApps
guiApps.guiBGchangeShow()
# guiApps.GuiWindowLAYOUTSshow()
# guiApps.GuiWithImageBUTTONSshow()




import ImageSAVER as study1
study1.ImgSaverSTUDY()


import ImagePathSEER as ips
ips.imagePathSeer("z-IMAGES_1/0.cool")

"""
import GuiGAMEsudoku as gui_game
gui_game.play()
"""


"""
import GuiAPPwithButtons as guiApp
guiApp.show()

import GuiGAMEpong as gui_game
gui_game.play()



import GuiWindowLAYOUTS as guiLayouts
guiLayouts.show()
"""


"""
import GuiSplashSCREEN as guiSplash
guiSplash.show()
"""

#Change the background automatically
import listAllFILES as lfs
folder_path="z-IMAGES_1/0.cool"
array = lfs.listAllFILES(folder_path)
length = array[0]
pics = array[1]

import BackgroundCHOOSE as bgcrand
bgcrand.BackgroundChooseRANDOM(array)




"""

import GuiHTMLlike as guiDesign
guiDesign.show()


import GuiWEATHER as guiWeather
guiWeather.show()

import GuiDATE as guiDate
guiDate.show()

import GuiImagesGALLERY as guiPhotoGallery
guiPhotoGallery.show()
"""


"""
import GuiWithImageBUTTONS as gui_images_first_try
gui_images_first_try.run()
"""

#import ImageSAVER as is1
#is1.imageSaver("premium wallpapers ready to eat chef prepared meals")


"""
import ProgressBAR as pb
pb.ProgressBAR(.1)
"""

"""
import RepeatSoOFTEN as repeat
repeat.RepeatSoOFTEN()
"""

"""
import ImageSAVER as is1
is1.imageSaver("premium wallpapers great snowy mountains",30)
is1.imageSaver("premium wallpapers green lush hills",30)
is1.imageSaver("premium wallpapers great mountains",30)
is1.imageSaver("premium wallpapers epic countrysides",30)
is1.imageSaver("premium wallpapers white clean apartment",30)
is1.imageSaver("premium wallpapers modern smart house",30)
"""


"""
#https://en.wikipedia.org/wiki/Insect_ecology
#https://en.wikipedia.org/wiki/Brewing
import PlainTextFromWikipediaURL as ptxt
text = ptxt.PlainTextFromWikipediaURL("https://en.wikipedia.org/wiki/Insect_ecology",True,False)
#text = ptxt.PlainTextFromURL("https://en.wikipedia.org/wiki/Brewing",False,False)
print(text)

import sayTHIS as st
st.sayTHIS(text) #defaults to "Hello World"
"""


