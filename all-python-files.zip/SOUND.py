
# import SOUND as sound
# sound.save200FramesFromVideo()

#----------------------


# import SOUND as sound
# sound.beep()

def beep(frequency=610, durationMs=500):
    import winsound
    winsound.Beep(frequency, durationMs) # 500, 1000
    # where 500 is the frequency in Herz
    #       1000 is the duration in miliseconds
#beep()




