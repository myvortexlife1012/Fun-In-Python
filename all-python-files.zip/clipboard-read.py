#run in the conda prompt:
#python clipboard-read.py

import ClipboardCHANGES as clipboard
clipboard.ClipboardChangesREAD()
