# FYI, ASTROLOGYfunctions is not this file ...

# Forum Here:
# http://www.linda-goodman.com/ubb/Forum1/HTML/017921.html

"""
"THE 30's"
Conjunction aspect  = 0 degrees
Semi-Sextile        = 30 degrees
Sextile aspect      = 60 degrees
Square aspect       = 90 degrees
Trine aspect        = 120 degrees
Quincunx aspect     = 150 degrees
Opposition Aspect   = 180 degrees


Triangles
Every complex pattern of Planetary Geometry is made up of triangles.





have both charts in the cached csv
replace sun in magi angles for Earth, or remove them?
#----------------

--MONEY ASTEROIDS--:
Financial Planets:
Venus, Neptune, Pluto, Chiron, Ceres, Sedna, Odin, Midas, Quaoar, Eris/UB313

Chiron, epic, personal and public trust, charisma, public image, public recognition, career, earning power
Gold 4955
Silver 5325
Abundantia 151
Fortuna 19
Bonus 10028
Midas 1981, epic for business, The most powerful of all financial astro-bodies.

Ceres, The “little godfather of business,” supercharges anything it touches, often selfish, materialistic, focused, goal-centric, can even be unethical at times.
Quaoar
Eris/UB313

Pallas, Logic, analysis, ordering and sequencing, organizing, plans.

Sappho, Anxiety, fear and panic, neurotic behavior, stock market crashes. Co-rules obsessions and compulsions with Pluto.

Odin, The emperor, the undisputed leader.

Vesta, Friendship, fans, loyalty, gentleness, harmony, compatibility, caring, giving, social relationships, trust, altruism.

Sedna, Sedna has no conscience whatsoever – success and expediency are all. It rules corruption, destruction, lies, immorality, disaster, upheaval, stolen wealth, and illegal gains.

#-------------------------------------------------------
# ASSIGN EACH PLANET: - to the categories of: Luck, Love, Sex, Drama ... Sedna is SuperDrama or Drama2 maybe
# any other main quality like that ... change Drama to Saturn Stress - stress is easier word than drama
#-------------------------------------------------------
Romance Planets:
Venus, Neptune, Chiron

Sexual Planets:
Venus, Mars, Pluto, Juno

Financial Planets:
Venus, Neptune, Pluto, Chiron, Ceres, Sedna, Odin, Midas, Quaoar, Eris/UB313

Creative Planets:
Venus and Neptune

Competitive Planets:
Mars, Pluto, Sedna

Charismatic Planets:
Chiron, Venus, Uranus, Vesta, Juno

Saturnian Planets:
Saturn and its midpoints, Sedna and its midpoints, Sappho

Obsessive Planets:
Pluto, Sappho


Saturnian Planets:
Saturn and its midpoints, Sedna and its midpoints, Sappho


Venus = ["Romance", "Sexual", "Financial", "Creative", "Charismatic"]
Neptune = ["Romance", "Financial", "Creative"]
Chiron = ["Romance", "Financial", "Charismatic"]
Mars = ["Sexual", "Competitive"]
Pluto = ["Sexual", "Financial", "Competitive"]
Juno = ["Sexual", "Charismatic"]
Ceres = ["Financial"]
Odin = ["Financial"]
Midas = ["Financial"]
Quaoar = ["Financial"]
ErisUB313 = ["Financial"]
Uranus = ["Charismatic", "Tech Stocks"]
Vesta = ["Charismatic"]
#--------------------------------------------
Saturn = ["Saturnian"]
Saturn's midpoints = ["Saturnian"]
Sappho = ["Saturnian"]
Sedna = ["Financial", "Competitive", "Saturnian"]
Sedna's midpoints = ["Saturnian"]
# planet = ["", "", "", "", ]


-----------

https://magiastrology.com/why_did_the_stock_market_go_up_218_points_today.php

Stock Market Surges UP
3/13/2012
9 Grand Trines

Six years ago, the Magi Society began to offer two software upgrades that included the following asteroids and planets:
Toro, Amor, Psyche, Eros, Urania, Lillith, Pandora, Icarus, Hidalgo, Diana, Sappho, Varuna, UB313/Eris, Peleus, Quaoar, Sedna, Ixion and Orcus.
All but two of these 18 extra AstroBodies made TRINES today.
There are 16 conjoined trines today.
The eight Grand Trines formed a central pattern that is Symmetrical.
Once again, Magi Astrology proves that it is the most accurate and useful astrology.

Jupiter, Venus, Pluto and Mars formed two of the nine Grand Trines.  But the other Grand Trines were formed by Toro, Amor, Psyche, Eros, Urania, Lillith, Pandora.






#----------------
Heliocentric  Astrology  does  not  have  a Sun  or  Moon,  or  houses,
or  ascendants  or midheavens, or retrograde planets. Heliocentric Astro    logy
ONLY has Planetary Geometry - and that is the cornerstone of Magi Astrology.
PLANETARY  GEOMETRY  and  the  position  of CHIRON. (Financial Astrology
 - JUPITER-CHIRON AND SATURN-CHIRON)

I LIKE THIS FORMAT:
JUNO LINKAGES 9

geo: 5

Juno conjunct Mars
Juno parallel Moon
Juno paralll URanus
Juno contraparallel Pluto
Juno parallel Juno

helio: 4

Chiron conjunct Juno
Juno conjunct Mars
Juno trine Jupiter
Juno quinkunx Chiron

Venus which is a very fast moving planet. ... slower the speed, the greater the power


LIKE CONJUNCTIONS - of parallel-ity
Geocentric:
A * Parallel * takes place between two planets whose declinations are
  at approximately the * SAME DEGREE * on the * SAME SIDE *, both North OR both South.
A * Contra-Parallel * takes place between two planets whose declinations are at
 approximately the * SAME DEGREE * on * DIFFERENT SIDES *, 1 North and 1 South

Heliocentric:
A Helio * Parallel *
Helio * Contra * latitude ... A Contra-Parallel aspect in the heliocentric dimension

MAGI GLOSSARY - https://magihelena.com/magi-astrology-glossary/


----------------------------------

INTRO TO MAGI 101

ORBS - 3 degrees, 1.2 degrees, .3 degrees  # ... https://magihelena.com/magi-astrology-lesson-planetary-geometry/

Enhancements
Favorable aspect angles in a natal chart. The Conjunction, Trine, and Parallel are enhancements. The Quincunx, Contra-parallel, and Contra-latitude are also enhancements if the aspect does not include a Saturnian planet. About Saturnian Planets

Pure Enhancements
The Conjunction, Trine, and Parallel

Linkages
Favorable aspect angles in a combined chart. The Conjunction, Trine, and Parallel are linkage aspects. The Quincunx, Contra-parallel, and Contra-latitude also form linkages if the aspect does not include a Saturnian planet. About Saturnian Planets

Clashes and Turbulent Aspects
Stressful aspect angles. All Squares and Oppositions are Clashes. Also considered to be Clashes are the Quincunx, Contra-parallel, and Contra-latitude if the aspect includes a Saturnian planet.

“Neutral” Aspects
Zodiac7one, Zodiac7two, and Zodiac7three aspects are considered inherently neutral – neither positive nor negative. Meanings for these aspects are drawn strictly from the Magi Planetary Symbolisms of the planets involved. Zodiac7 aspects follow the same rules as the Quincunx, Contra-parallel, and Contra-latitude: they are linkages if neither planet is a Saturnian planet. Zodiac7 aspects are clashes if either planet is a Saturnian planet. About Magi Planetary Symbolisms



All Planetary Geometry is powerful, but all patterns are not equally powerful. Several factors determine the relative power of a geometrical pattern.

Number of Planets: The power of Planetary Geometry is directly proportional to the number of planets that form the Planetary Geometry – the more planets involved, the more powerful the Planetary Geometry.

Exactness: Although all Magi orbs are fairly tight, the more exact the aspects forming Planetary Geometry, the more powerful the geometry.

Symmetry: Patterns which are symmetrical are much more powerful than asymmetrical patterns. The Grand Trine, Flying Eagle, Fortress, T-Square and the declination/latitude pattern B shown above are examples of Symmetrical Planetary Geometry. The Mystical Triangle and the declination/latitude pattern A above are examples of Non-Symmetrical Planetary Geometry.

Rarity: All Planetary Geometry is powerful, but rare Planetary Geometry is even more powerful- the more rare the Planetary Geometry, the more power it has. The rarest Planetary Geometry is comprised of the most complex patterns and of the most planets.


interpretation really boils down to this * BASIC FORMULA *:

Aspects & Geometry are interpreted by combining:

A. the Meaning of the Planetary Geometry or Aspect, with
B. the Magi Symbolisms of the planets involved.


Planet symbolism meanings - MAGI:  # ... https://magihelena.com/magi-astrology-lesson-planets-meanings/

Chiron
Soulmates, true love, marriage, serious courtship, promises, commitments, vows, fertility, pregnancy, family, children, parenthood, lovemaking, kindred spirits, karmic ties, reincarnation, the New Age, progress, free will, actual freedom (Uranus rules the urge for freedom) free enterprise and free trade, personal and public trust, charisma, public image, public recognition, career, earning power. Co-rules life and death with Neptune. Reincarnation.

Vesta
Friendship, fans, loyalty, gentleness, harmony, compatibility, caring, giving, social relationships, trust, altruism.

Ceres
The “little godfather of business,” supercharges anything it touches, often selfish, materialistic, focused, goal-centric, can even be unethical at times.

Pallas
Logic, analysis, ordering and sequencing, organizing, plans.

Sedna
Sedna has no conscience whatsoever – success and expediency are all. It rules corruption, destruction, lies, immorality, disaster, upheaval, stolen wealth, and illegal gains.

Sappho
Anxiety, fear and panic, neurotic behavior, stock market crashes. Co-rules obsessions and compulsions with Pluto.

Odin
The emperor, the undisputed leader.

Midas
The most powerful of all financial astro-bodies.

Quaoar
A financial planet.

Eris/UB313
A financial planet.

Isis
Gives the desire and ability to marry into royalty.

Saturn/Chiron Midpoint
The Heartbreak Midpoint. Operates similarly to a Saturn-Chiron Heartbreak Clash. May create initial attraction in a combined chart but usually leads to disaster. Devastating mistakes, bad judgment, being seen at your worst, failure. More about the Heartbreak Midpoint

Saturn/Jupiter Midpoint
The Nuclear Midpoint. Operates similarly to a Saturn-Jupiter Nuclear Clash. May create initial attraction in a combined chart but usually leads to irreconcilable differences. Devastating mistakes, bad judgment, confusion, agitation, distress, overwhelm. More about the Nuclear Midpoint

Jupiter/Chiron Midpoint
A Cinderella and Golden Midpoint. Operates similarly  to a Jupiter-Chiron enhancement. Helpful in both career and love.

...
YOU MUST:
Only use Magi Aspects and Magi Orbs

Aspect 	Angle	Orb
Aspect

Orb
Conjunction	0°	3°				Geo Parallel	1.2°
Trine	120°	3°				Geo Contra-parallel	1.2°
Square	90°	  3°				Helio Parallel	0.3°
Quincunx	150°	3°			Helio Contra-latitude	0.3°
Opposition	180°	3°
Zodiac7one*	51.429°	3°
Zodiac7two*	102.858°  3°
Zodiac7three*	154.117°	3°


Natalization Basics:

Use all 6 Dimensions of Magi Astrology
Only use Magi Aspects and Magi Orbs
Focus on Planetary Geometry
Only use Magi Planetary Symbolisms
Avoid the most pernicious Clashes
Understand Magi terminology


The Magical Angle - made by - CHIRON (the planet that RULES CINDERELLA)

Earth Like The Sun... in Heliocentric
In heliocentric astrology, there is no Sun at all, just as there is no Earth in geocentric astrology. Instead of the Sun, heliocentric astrology has the Earth, which according to Magi Astrology is very similar to the Sun.

Helio will Agree with Geo - Complimentary
if you apply the principles of Magi Astrology, the Heliocentric Chart is COMPLIMENTARY to the geocentric chart and the Heliocentric Chart is NEVER CONTRADICTORY of the geocentric chart.  In Magi Astrology, when you use the Heliocentric Chart, it is like looking at the same statue from a different angle


MAGICAL LINKAGES HELP A PERSON TO ACHIEVE MAGICAL SUCCESS

A good day to get married:
the two Cinderella Aspects that existed on the day of Jordan's wedding

#----------------------
PROGESSIONS: How will it be later, after the date - for business, other, etc...
#----------------------
Each day after an event, represents the following year's quality - for that event
Pure Progressions- the chart of the sky 10 days after a wedding date is read as the chart of the pure progressions for the marriage’s 10th year.
How will it be 1 year after? Check 1 day after event's day - and do a CAC combined chart
#----------------------
2 types of checking for the future:
Pure Progressions - (1 chart) the chart of the sky 10 days after a wedding date is read as the chart of the pure progressions for the marriage’s 10th year. This chart’s linkages and clashes define the major stellar influences on the marriage for the time.
Progressed Transits - (2 charts) the chart for the progressed transits for the 10th year of the marriage would be the aspects in the CAC (Combined Alignment Chart) BETWEEN the 10th day after the wedding and the chart of the wedding date. The applying linkages and clashes in this CAC also define the time period for the marriage, though less strongly than the Pure Progressions.
 ... # ... https://magihelena.com/magi-astrology-lesson-natalizations/

Applying:  A planet which is moving toward an exact aspect. See Exact, Aspect.
Applying aspects ARE more powerful that separating aspects




Names of New Linkages:

their synastry:

CHIRON LINKAGES 9

in the geo:

Mercury trine Chiron
Chiron trine Neptune
Uranus contraparalleL Chiron#

in the helio:

Chiron conjunct Juno
Juno quinkunx Chiron
Mercury latitude Chiron
Uranus latitude Chiron
Chiron contralatitude Venus
Chiron latitude Neptune

CHIRON ACTIVATIONS: 3

geo:

Uranus opposite Chiron
Jupiter square Chiron

helio:

Chiron square Saturn

JUNO LINKAGES 9

geo: 5

Juno conjunct Mars
Juno parallel Moon
Juno paralll URanus
Juno contraparallel Pluto
Juno parallel Juno

helio: 4

Chiron conjunct Juno
Juno conjunct Mars
Juno trine Jupiter
Juno quinkunx Chiron

JUNO CLASHES 1

geo:

Saturn square Juno

helio:

-


SATURN LINKAGES: 3

geo:

Saturn trine Moon

helio:

Jupiter latitude Saturn
Saturn latitude Jupiter

SATURN CLASHES: 12

geo: 7

Jupiter opposite Saturn
Mercury contraparallel Saturn
Venus contraparallel Saturn
Jupiter contraparallel Saturn
Saturn square Juno
Saturn contraparlalel Mars
Saturn contraparallel Neptune

helio: 5

Chiron square Saturn
Mars contralatitude Saturn
Uranus contralatitude SAturn
Saturn quinkunx Venus
Saturn contralatitude Neptune


CINDERELLA LINKAGES: 3

geo: 1

Chiron trine Neptune

helio: 2

Chiron contralatitude Venus
Chiron latitude Neptune


ROMANCE LINKAGES: 8

geo:5

Sun conjunct Venus
Sun parallel Venus
Venus conjunct Neptune
Venus parallel Neptune
Chiron trine Neptune

helio: 3

(Venus contralatitude VEnus)
Neptune latitdue Venus
Chiron contralatiude Venus
Chiron latitude Neptune

SEXUAL LINKAGES:

geo: 3

Juno conjunct Mars
Venus parallel Mars
Juno contraparallel Pluto

helio: 3

Chiron conjunct Juno
Juno quinkunx Chiron
Juno conjunct Mars


And regarding planetary geometry, there are two super romance linkages, only consisting of the romance planets.

in the geo:

His Venus conjunct (and parallel) her Neptune and trine his Chiron

in the heliocentric latitudes:

His Neptune and Chiron are latitude her Venus and Neptune and all these planets are contralatitude her Venus.


That is what I call one mess of a synastry from heaven and hell. lol At least according to magi rules.

DD

#----------------------------


# Forum Here:
# http://www.linda-goodman.com/ubb/Forum1/HTML/017921.html

#------------
Summary of Magi:
#------------
Magi use linkages and aspects. In synastry they are linkages, in transits they are aspects.
Magi uses the following orbs -

Geo synastry - 3'
declinations - 1.2'

Helio synastry - 3'
declination - 0.3'

SEXUAL LINKAGES
Juno-Mars
Juno-Pluto
venus-pluto
mars-pluto
venus-mars
chiron-juno = emotional involvement
venus-juno = non committal relationship/affairs
venus-uranus = sex without commitment

mars-chiron = marital sexual linkage
sun-chiron = trust linkage
venus-jupiter = loyal linkage
sun-venus = cupid linkage
chiron-uranus = reluctance to marry

ROMANCE ASPECTS/CINDERELLA'S
chiron-venus = MAGICAL LINKAGE / CINDERELLA
chiron-neptune = LIFETIME LINKAGE / CINDERELLA
venus-neptune = romance linkage
chiron - jupiter = CINDERELLA
chiron-uranus = CINDERELLA business/fame linkage
chiron-pluto = CINDERELLA


BAD TRANSITS (aspects of 90'/150'/180'/contra-parallel)

chiron-saturn = HEARTBREAK TRANSIT
saturn-jupiter = NUCLEAR transit
saturn-neptune = saturn clash

BAD LINKAGES (aspects of 90'/150'/180'/contra-parallel)
saturn-jupiter = nuclear clash
saturn-chiron = nuclear clash

# http://www.linda-goodman.com/ubb/Forum1/HTML/017921.html


More Helio talk:
2. his chiron parallel my venus - magical cinderella
3. my chiron parallel his venus - magical cinderella


GEO SEXUAL LINKAGES:
mars parallel mars
mars trine pluto

HELIO SEXUAL LINKAGES:
mars parallel pluto
mars square pluto
mars parallel venus
chiron quincunx juno - long-term partners link



A complete astrology needs to take into account all of the following:
- Planetary Geometry including the declinations
- Heliocentric Astrology including the latitudes
- Chiron
- The four major asteroids
- Planetary Synchronizations
- Chaotic Triangles


We advise that you always pay attention to YOUR OWN TRANSITS because we have found that it is
just about impossible to make money trading stocks while you are having
Turbulent Money Transits.
(For example, while transiting Saturn is applying and within 0.6 degrees
of making an exact Turbulent Angle to your natal Chiron, Pluto, Neptune, Venus or Jupiter.)



Venus quincunx Neptune
Saturn contra-parallel Neptune
Saturn parallel Sun
Sun contra-parallel Neptune
Venus parallel Jupiter
Venus parallel Uranus
Jupiter parallel Uranus




THE LAST JUPITER-CHIRON CONTRA-PARALLEL TIMED A HIGH WITHIN 3 DAYS:

A Saturn-Chiron Clash is helpful in TIMING LOWS in the financial markets,
  whereas a Jupiter-Chiron Magical Angle is helpful in TIMING HIGHS in the financial markets.

-TEST DATE 1-
THE PEAK - On October 5, 1997, Jupiter and Chiron formed
  an exact contra-parallel in the latitudes in the heliocentric sky




The Magi Society has revealed several times that stock and commodity markets are most likely to make highs when the planets make the following types of magical Planetary Geometry:

- Symmetrical Patterns formed by at least four planets
- Grand Trines
- Conjoined Trines
- Triple Conjunctions
- Triple Parallels

The above 5 alignments are Golden Alignments.
As the planets are moving towards the formation of any Golden Alignment, the planets pull stock prices higher, like adding helium air to a balloon.
When planets disperse and move away from being in Golden Alignment, stock prices move lower, like letting air out of a balloon.

-TEST DATE 2-
For example, the all time high in the S & P 500 was made on Oct. 10, 2007 when there was a super Golden Alignment of seven planets all helping to form a symmetrical pattern.
NOTE: the Golden Alignment was made in the Zodiac7 ...  a Zodiac7 7-planet symmetrical pattern on that day when stock prices made an all time high.


whenever Jupiter and Saturn combine to be part of a symmetrical pattern, their symbolism is "unlimited."

-Trans-Neptunian Dwarf Planets-
By including the Trans-Neptunian Dwarf Planets, we now better understand
the astrological reasons for the vast majority of tops in stock and commodity prices.


Quaoar is a Trans-Neptunian Dwarf Planet - Chiron and Venus are classic Financial Planets.� Ceres is the little godfather of business, so it is a minor financial planet.� The more financial planets there are in a symmetrical pattern, the more influence the pattern has on financial events, such as a high in stock markets.

------------------
You can see in the above chart that May 2, 2011 was an important high for stocks.
After that date, the stock market did a zigzag and then fell precipitously,
making a low on Oct. 4, 2011.

But then stocks made a
-> "recovery high" on October 27, 2011.

... The principles of Magi Astrology ... would - predict that an important Golden Alignment
- would exist on October 27, 2011,
the day of the recovery high.

Magi Astrology is correct
- there was a Golden Alignment on October 27, 2011.

October 29, 2011
Grand Trines are Golden Alignments and there was a Grand Trine formed
 by Mars, UB313/Eris and Quaoar.
And once again, any astrologer who did not utilize UB313/Quoaor would not have seen this Golden Alignment.


------------------

-Incorporation Date-

4 Financial Planets and they are Venus, Chiron, Neptune and Pluto
 - whenever any two of these planets make a MAGIcal angle to each other,
 - the two Financial Planets form what we call a FINANCIAL SUPER ASPECT.

The MAGIcal angles are the conjunction, trine, quincunx, parallel and contra-parallel. GEO-HELIO

NOTE:
We also explained that almost all of the super successful companies were incorporated
on a day that has a Financial Super Aspect.

----------

From many years of experience the Magi Society has discovered that
when the stock prices of the -companies that are the leaders- peak, -> so does the entire stock market.

----

The other techniques of Magi Solar Progressions are taught in the * Progressions * Manual *,
which we provide to only members who purchase our special software upgrade known as
the Financial Astrology Predictive Upgrade




"""
# Venus, Neptune, Pluto, Chiron, Ceres, Sedna, Odin, Midas, Quaoar, Eris/UB313
# import ASTROLOGYmagi as m
# m.financialMagi
financialMagi = {
    0: "Venus",
    1: "Neptune",
    2: "Pluto",
    3: "Chiron",
    4: "Ceres",
    5: "Sedna",
    6: "Odin",
    7: "Midas",
    8: "Quaoar",
    9: "ErisUB313"
}

# also linkages - Quincunx and the Contra-Parallel - IF THERE'S NO SATURNIAN PLANET

"""
Planetary Synchronization ... for what is going on - and what is to come

These are all of the angles I'm allowed to use - officially

#Aspect 	Angle	Orb
Conjunction	0°	3°
Trine	120°	3°
Square	90°	3°
Quincunx	150°	3°
Opposition	180°	3°
Zodiac7one*	51.429°	3°
Zodiac7two*	102.858°  3°
Zodiac7three*	154.117°	3°

Aspect  Orb
Geo Parallel	1.2°
Geo Contra-parallel	1.2°
Helio Parallel	0.3°
Helio Contra-latitude	0.3°

"""


# planets_organized["Sun"]["planet_orb"], planets_organized["Sun"]["power"]

# import ASTROLOGYmagi as m
# addPowersIn = m.set_savedPowerValues['initial_chemistry']['power']['Luck']
# ONE BIG SET - 6 times we do MagiAspect Scans - for matches--saving power values
# set_savedPowerValues['initial_chemistry']['power']
# import ASTROLOGYmagi as m
# m.set_savedPowerValues
set_savedPowerValues = {
    'initial_chemistry': {'finalGrade': 0, 'power': {'Luck': 0, 'Love': 0, 'Sex': 0, 'Drama': 0}},
    'the_potiential_relationship': {'finalGrade': 0, 'power': {'Luck': 0, 'Love': 0, 'Sex': 0, 'Drama': 0}},
    'how_you_feel_about_it': {'finalGrade': 0, 'power': {'Luck': 0, 'Love': 0, 'Sex': 0, 'Drama': 0}},
    'how_they_feel_about_it': {'finalGrade': 0, 'power': {'Luck': 0, 'Love': 0, 'Sex': 0, 'Drama': 0}},
    'how_the_relationship_affects_you': {'finalGrade': 0, 'power': {'Luck': 0, 'Love': 0, 'Sex': 0, 'Drama': 0}},
    'how_the_relationship_affects_them': {'finalGrade': 0, 'power': {'Luck': 0, 'Love': 0, 'Sex': 0, 'Drama': 0}},
    'combinedFinalGrade':0
}

# import ASTROLOGYmagi as m
# m.set_savedLinkages
set_savedLinkages = {
    'initial_chemistry': {'finalGrade': 0, 'linkages': {'Luck': {}, 'Love': {}, 'Sex': {}, 'Drama': {}}},
    'the_potiential_relationship': {'finalGrade': 0, 'linkages': {'Luck': {}, 'Love': {}, 'Sex': {}, 'Drama': {}}},
    'how_you_feel_about_it': {'finalGrade': 0, 'linkages': {'Luck': {}, 'Love': {}, 'Sex': {}, 'Drama': {}}},
    'how_they_feel_about_it': {'finalGrade': 0, 'linkages': {'Luck': {}, 'Love': {}, 'Sex': {}, 'Drama': {}}},
    'how_the_relationship_affects_you': {'finalGrade': 0, 'linkages': {'Luck': {}, 'Love': {}, 'Sex': {}, 'Drama': {}}},
    'how_the_relationship_affects_them': {'finalGrade': 0, 'linkages': {'Luck': {}, 'Love': {}, 'Sex': {}, 'Drama': {}}},
    'combinedFinalGrade':0
}

# import ASTROLOGYmagi as m
# m.signStartingDegrees
signStartingDegrees = {"Aries": 0, "Taurus": 30, "Gemini": 60, "Cancer": 90, "Leo": 120, "Virgo": 150, "Libra": 180, "Scorpio": 210,
           "Sagittarius": 240, "Capricorn": 270, "Aquarius": 300, "Pisces": 330, }

# import ASTROLOGYmagi as m
# m.signs12
signs12 = "Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo", "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"

# import ASTROLOGYmagi as m
# m.planets12
planets12 = "Sun", "Moon", "Mercury", "Venus", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune", "Pluto", "Juno", "Chiron"

# -------------------------------------------------
# -------------------------------------------------
# -------------------------------------------------

# below are the following vars:
# VAR 1:
# specialAspects  # all of the linkages on file so far
#
# note: when looping, I'm losing the end, maybe the last entry - check on that (when looping over all the linkages)

# -------------------------------------------------
# -------------------------------------------------
# -------------------------------------------------

# below are the following vars:
# VAR 1:
# aspects_organized  # types of degrees - name of them, Conjunct, Trine, Sextile, and stuff about them ... including a *definition*! as well
#
#
# VAR 2:
# planets_organized  # they each have the order number, planet_orb, and the power number
#
#
# the order: #'Sun','Moon','Mercury','Venus','Mars','Jupiter','Saturn','Uranus','Neptune','Pluto','NorthNode','SouthNode','Chiron','Ceres','Pallas','Juno','Vesta','Eros','Amor','Sappho','Lilith','SunMoonMidpoint','Fortune','Ascendant','II','III','IV','V','VI','Descendant','VIII','IX','Midheaven','XI','XII'




#******************** ASPECTS ORGANIZED (types) ***************************#

# -------------------------------------------------
# aspects_organized #types of degrees - name of them, Conjunct, Trine, Sextile, and stuff about them
#
#magiAngles = aspects_organized
# import ASTROLOGYmagi as m
# m.aspects_organized
aspects_organized = {

    'Conjunct': {
        'class': 'Major',
        'degrees': 0,
        'meaningful_orb': 10,
        'power': 15,
        'definition': "Harmonious-Dynamic: Usually Imparts Power - Close Bond and Merging of Energies - Continually Influence Eachother - Same Energy {Moon/Venus or Sun/Mars} Increased Potential - Otherwise its Inhibited",
    },

    'Trine': {
        'class': 'Major',
        'degrees': 120,
        'meaningful_orb': 6.5,
        'power': 10,
        'definition': "Harmonious: Easy flow - passive - Cosmic Gift - Supportive and Helpful, This Energy Comes Naturally and FREE - Planets are usually in Same Element but different Quality - But if Too many Trines, Laziness might Develop since things are too easy",
    },

    'Sextile': {
        'class': 'Major',
        'degrees': 60,
        'meaningful_orb': 5,
        'power': 8,
        'definition': "Harmonious-Dynamic: Less-Automatic Harmonious Quality - Opportunity To Sieze {up to you since it can be non-committal} - Usually Imparts Opportunity, Reaching Out - Easier to TAP ENERGY when Planets are similar, Moon-Venus, Sun-Mars",
    },

    'Quincunx': {
        'class': 'Minor',
        'degrees': 150,
        'meaningful_orb': 3,
        'power': 6,
        'definition': "Harmonious-Dynamic: Indicates Potiential, DESIRE, Longing, New Possibilities - Exuberant, Occasionally Too Much So {lacking restraint} - Imparts Edgy, nagging, Strong SPURRING Onward - Positive Except with Saturn",
    },

    'Septile': {
        'class': 'Ternary',
        'degrees': 51.428,
        'meaningful_orb': 3,
        'power': 4,
        'definition': "Harmonious: Imparts rising to the occasion - If You're Sensitive to it, you will want to Deeply Discover and Experience the Full Potential of 2 Planets Energies -- Not To Express Anything, but Just to Experience It",
    },

    'Quintile': {
        'class': 'Minor',
        'degrees': 72,
        'meaningful_orb': 5,
        'power': 6,
        'definition': "Harmonious: Imparts Powerful Drive, Aptitude, Skill, Proficiency - Creative, Artistic, Talent and Potential - DESIRE and ABILITY to Find Creative and Artistic Solutions to Overcome the Existing Status Quo",
    },

    'Semiquintile': {
        'class': 'Ternary',
        'degrees': 36,
        'meaningful_orb': 2,
        'power': 4,
        'definition': "Harmonious: Imparts ability to help others - Indicate Hidden Artistic Talents that can Emerge When an Individual is Sensitive to their Presence",
    },

    'Biquintile': {
        'class': 'Minor',
        'degrees': 144,
        'meaningful_orb': 2,
        'power': 6,
        'definition': "Harmonious: Imparts Creative Talent, Knowledge, Balance - complementary - For The Artistic and Sensitive Person - helps to Develop Creative Powers, Find Original Solutions, and Positively Light Initially Problematic Issues",
    },

    'Novile': {
        'class': 'Ternary',
        'degrees': 40,
        'meaningful_orb': 1,
        'power': 6,
        'definition': "Neutral: Imparts Constraints and Limits - Fated compulsions - dealing with creativity, completion, realization",
    },

    'Opposed': {
        'class': 'Major',
        'degrees': 180,
        'meaningful_orb': 10,
        'power': -10,
        'definition': "Disharmonious-Dynamic: Imparts Motivation and Energy to seek balance in Conflict - Transform the Energy, to strengthen each other, work together - Weaker Polarity's Energy is experienced as Projection - and Alternating phases can happen between the two",
    },

    'Square': {
        'class': 'Major',
        'degrees': 90,
        'meaningful_orb': 6,
        'power': -10,
        'definition': "Disharmonious: Imparts challenge and Irritation - Analytical Aspect that creates tension and challenges us to work and learn",
    },

    'Sesquisquare': {
        'class': 'Minor',
        'degrees': 135,
        'meaningful_orb': 3,
        'power': -6,
        'definition': "Disharmonious: Imparts a difficult spurring onward to Achieve Harmony - irritating - Analytical Aspect that creates tension and challenges us to work and learn",
    },

    'Semisquare': {
        'class': 'Minor',
        'degrees': 45,
        'meaningful_orb': 3,
        'power': -6,
        'definition': "Disharmonious: Imparts deep challenge and irritation",
    },

    'Semisextile': {
        'class': 'Minor',
        'degrees': 30,
        'meaningful_orb': 2,
        'power': -6,
        'definition': "Nuetral: Imparts a nagging spurring onward - Create chances to work constructively out of the difficulties",
    },

}
# import ASTROLOGYmagi as m
magiAngles = aspects_organized
# import ASTROLOGYmagi as m
# m.magiAngles

# --------------------------------------
# -------PLANETS------------------------
# --------------------------------------

# 'Sun','Moon','Mercury','Venus','Mars','Jupiter','Saturn','Uranus','Neptune','Pluto','NorthNode','SouthNode','Chiron','Ceres','Pallas','Juno','Vesta','Eros','Amor','Sappho','Lilith','SunMoonMidpoint','Fortune','Ascendant','II','III','IV','V','VI','Descendant','VIII','IX','Midheaven','XI','XII'
# it has their order, which one's first, second ... and the planet_orb, and the power number


#******************** PLANETS ORGANIZED (details) ***************************#

# they each have the order number, planet_orb, and power number
# planets_organized["Sun"]["planet_orb"], planets_organized["Sun"]["power"]

# import ASTROLOGYmagi as m
# m.planets_organized
planets_organized = {

    'Sun': {
        'order': 1,
        'planet_orb': 15, #if the difference is less or equal to this planet_orb - times the % diff with this power - and times that power with the other power1
        'power': 15,
    },

    'Moon': {
        'order': 2,
        'planet_orb': 12,
        'power': 10,
    },

    'Mercury': {
        'order': 3,
        'planet_orb': 7,
        'power': 7,
    },

    'Venus': {
        'order': 4,
        'planet_orb': 7,
        'power': 7,
    },

    'Mars': {
        'order': 5,
        'planet_orb': 7,
        'power': 7,
    },

    'Jupiter': {
        'order': 6,
        'planet_orb': 9,
        'power': 9,
    },

    'Saturn': {
        'order': 7,
        'planet_orb': 9,
        'power': 9,
    },

    'Uranus': {
        'order': 8,
        'planet_orb': 5,
        'power': 5,
    },

    'Neptune': {
        'order': 9,
        'planet_orb': 5,
        'power': 5,
    },

    'Pluto': {
        'order': 10,
        'planet_orb': 5,
        'power': 5,
    },

    'NorthNode': {
        'order': 11,
        'planet_orb': 5,
        'power': 5,
    },

    'SouthNode': {
        'order': 12,
        'planet_orb': 5,
        'power': 5,
    },

    'Chiron': {
        'order': 13,
        'planet_orb': 5,
        'power': 5,
    },

    'Ceres': {
        'order': 14,
        'planet_orb': 5,
        'power': 5,
    },

    'Pallas': {
        'order': 15,
        'planet_orb': 5,
        'power': 5,
    },

    'Juno': {
        'order': 16,
        'planet_orb': 5,
        'power': 5,
    },

    'Vesta': {
        'order': 17,
        'planet_orb': 5,
        'power': 5,
    },

    'Eros': {
        'order': 18,
        'planet_orb': 5,
        'power': 5,
    },

    'Amor': {
        'order': 19,
        'planet_orb': 5,
        'power': 5,
    },

    'Sappho': {
        'order': 20,
        'planet_orb': 5,
        'power': 5,
    },

    'Lilith': {
        'order': 21,
        'planet_orb': 5,
        'power': 5,
    },

    'SunMoonMidpoint': {
        'order': 22,
        'planet_orb': 5,
        'power': 5,
    },

    'Fortune': {
        'order': 23,
        'planet_orb': 5,
        'power': 5,
    },

    'Ascendant': {
        'order': 24,
        'planet_orb': 5,
        'power': 5,
    },

    'Descendant': {
        'order': 25,
        'planet_orb': 5,
        'power': 5,
    },

    'Midheaven': {
        'order': 26,
        'planet_orb': 5,
        'power': 5,
    },

    'SaturnChironMidpoint': {
        'order': 27,
        'planet_orb': 5,
        'power': 5,
    },
}

# -------------------------------------------------
# -------------------------------------------------
# -------------------------------------------------



# import ASTROLOGYmagi as m
# specialAspects = m.magiAspects()
# print(f"magi: {magi}")

# returns the array - below
def magiAspects():
    pass
    #return specialAspects


# returns the array - below
# import ASTROLOGYmagi as m
# aspects_organized = m.magiAspects2()
def magiAspects2():
    return aspects_organized


# returns the array - below
# import ASTROLOGYmagi as m
# planets_organized = m.magiAspects3()
def magiAspects3():
    return planets_organized



# import ASTROLOGYmagi as m
# m.magiAspects()




# -------------------------------------------------
# -------------------------------------------------
# -------------------------------------------------


# 'The-Potiential-Relationship'
# 'The-Initial-Compatibility'
# 'How-You-Feel-About-It'
# 'How-They-Feel-About-It'
# 'How-The-Relationship-Affects-You'
# 'How-The-Relationship-Affects-Them'
# 'Your-Cosmic-Rating'


"""
1. Jupiter-Pluto (Super Success Aspect)
8. Jupiter-Neptune
2. Venus-Pluto
9. Uranus-Venus
3. Pluto-Sun
10. Neptune-Venus
4. Uranus-Pluto (has a 1 degree orb for Declinations)
11. Uranus-Sun
5. Jupiter-Sun
12. Neptune-Sun
6. Jupiter-Venus (Aspect of Champions)
13. Jupiter-Chiron
7. Jupiter-Uranus (Super Fame Aspect & Historic Aspect)
14. Venus-Chiron
"""

AspectsDict = {
    # copy it in
}

#******************** SPECIAL ASPECTS ***************************#

# import ASTROLOGYmagi as m
# 'Sun','Moon','Mercury','Venus','Mars','Jupiter','Saturn','Uranus','Neptune','Pluto','NorthNode','SouthNode','Chiron','Ceres','Pallas','Juno','Vesta','Eros','Amor','Sappho','Lilith'

# -------------------------------------------------
# -------------------------------------------------
# -------------------------------------------------

# below are the following vars:
# VAR 1:
# aspects_organized  # types of degrees - name of them, Conjunct, Trine, Sextile, and stuff about them ... including a *definition*! as well
#
#
# VAR 2:
# planets_organized  # they each have the order number, planet_orb, and the power number
#
#
# the order: #'Sun','Moon','Mercury','Venus','Mars','Jupiter','Saturn','Uranus','Neptune','Pluto','NorthNode','SouthNode','Chiron','Ceres','Pallas','Juno','Vesta','Eros','Amor','Sappho','Lilith','SunMoonMidpoint','Fortune','Ascendant','II','III','IV','V','VI','Descendant','VIII','IX','Midheaven','XI','XII'


# -------------------------------------------------
# -------------------------------------------------
# -------------------------------------------------

#----------
#create the file output - and then open it - like it's outputting to tkinter
#----------
# import ASTROLOGYmagi as m
# m.AspectsDictSelf
AspectsDictSelf = { #264 total
#----------------------------------------------------------
#SUN - LUCK
    0:{},
    1:{ 'word3':'Sun-Conjunct-Mars', 'cat': ['Luck'] },
    2:{ 'word3':'Sun-Conjunct-Jupiter', 'cat': ['Luck'] },
    3:{ 'word3':'Sun-Conjunct-Neptune', 'cat': ['Luck'] },
    4:{ 'word3':'Sun-Conjunct-Uranus', 'cat': ['Luck'] },
    5:{ 'word3':'Sun-Conjunct-Pluto', 'cat': ['Luck'] },
    6:{ 'word3':'Sun-Trine-Mars', 'cat': ['Luck'] },
    7:{ 'word3':'Sun-Trine-Jupiter', 'cat': ['Luck'] },
    8:{ 'word3':'Sun-Trine-Neptune', 'cat': ['Luck'] },
    9:{ 'word3':'Sun-Trine-Pluto', 'cat': ['Luck'] },
    10:{ 'word3':'Sun-Trine-Chiron', 'cat': ['Luck', 'Love|f'] },
    11:{ 'word3':'Sun-Trine-Uranus', 'cat': ['Luck'] },
    12:{ 'word3':'Sun-Quincunx-Mars', 'cat': ['Luck'] },
    13:{ 'word3':'Sun-Quincunx-Neptune', 'cat': ['Luck'] },
    14:{ 'word3':'Sun-Quincunx-Jupiter', 'cat': ['Luck|b'] },
    15:{ 'word3':'Sun-Quincunx-Uranus', 'cat': ['Luck|b'] },
    16:{ 'word3':'Sun-Quincunx-Pluto', 'cat': ['Luck|b'] },
    17:{ 'word3':'Sun-Quincunx-Chiron', 'cat': ['Luck', 'Love|f'] },
    18:{ 'word3':'Sun-Semisextile-Pluto', 'cat': ['Luck'] },
# MERCURY - LUCK
    19:{ 'word3':'Mercury-Conjunct-Mars', 'cat': ['Luck'] },
    20:{ 'word3':'Mercury-Trine-Mars', 'cat': ['Luck'] },
# VENUS - LUCK
    21:{ 'word3':'Venus-Conjunct-Mars', 'cat': ['Luck', 'Sex'] },
    22:{ 'word3':'Venus-Conjunct-Jupiter', 'cat': ['Luck', 'Love'] },
    23:{ 'word3':'Venus-Conjunct-Uranus', 'cat': ['Luck', 'Sex'] },
    24:{ 'word3':'Venus-Conjunct-Neptune', 'cat': ['Luck', 'Love', 'Sex'] },
    25:{ 'word3':'Venus-Conjunct-Pluto', 'cat': ['Luck', 'Sex'] },
    26:{ 'word3':'Venus-Conjunct-Chiron', 'cat': ['Luck', 'Love'] },
    27:{ 'word3':'Venus-Trine-Mars', 'cat': ['Luck', 'Sex'] },
    28:{ 'word3':'Venus-Trine-Jupiter', 'cat': ['Luck', 'Love'] },
    29:{ 'word3':'Venus-Trine-Uranus', 'cat': ['Luck', 'Sex'] },
    30:{ 'word3':'Venus-Trine-Neptune', 'cat': ['Luck', 'Love', 'Sex'] },
    31:{ 'word3':'Venus-Trine-Pluto', 'cat': ['Luck', 'Sex'] },
    32:{ 'word3':'Venus-Trine-Chiron', 'cat': ['Luck', 'Love'] },
    33:{ 'word3':'Venus-Quincunx-Jupiter', 'cat': ['Luck', 'Love'] },
    34:{ 'word3':'Venus-Quincunx-Uranus', 'cat': ['Luck', 'Sex'] },
    35:{ 'word3':'Venus-Quincunx-Neptune', 'cat': ['Luck', 'Love', 'Sex'] },
    36:{ 'word3':'Venus-Quincunx-Pluto', 'cat': ['Luck', 'Sex'] },
    37:{ 'word3':'Venus-Quincunx-Chiron', 'cat': ['Luck', 'Love'] },
# MARS - LUCK
    38:{ 'word3':'Mars-Conjunct-Jupiter', 'cat': ['Luck'] },
    39:{ 'word3':'Mars-Conjunct-Uranus', 'cat': ['Luck', 'Drama', 'Sex'] },
    40:{ 'word3':'Mars-Conjunct-Neptune', 'cat': ['Luck', 'Sex'] },
    41:{ 'word3':'Mars-Conjunct-Pluto', 'cat': ['Luck', 'Sex'] },
    42:{ 'word3':'Mars-Conjunct-Chiron', 'cat': ['Luck', 'Sex'] },
    43:{ 'word3':'Mars-Trine-Jupiter', 'cat': ['Luck'] },
    44:{ 'word3':'Mars-Trine-Saturn', 'cat': ['Luck'] },
    45:{ 'word3':'Mars-Trine-Uranus', 'cat': ['Luck', 'Sex|m'] },
    46:{ 'word3':'Mars-Trine-Neptune', 'cat': ['Luck', 'Sex'] },
    47:{ 'word3':'Mars-Trine-Pluto', 'cat': ['Luck', 'Sex'] },
    48:{ 'word3':'Mars-Trine-Chiron', 'cat': ['Luck', 'Sex'] },
# JUPITER - LUCK
    49:{ 'word3':'Jupiter-Conjunct-Uranus', 'cat': ['Luck'] },
    50:{ 'word3':'Jupiter-Conjunct-Neptune', 'cat': ['Luck'] },
    51:{ 'word3':'Jupiter-Conjunct-Pluto', 'cat': ['Luck'] },
    52:{ 'word3':'Jupiter-Conjunct-Chiron', 'cat': ['Luck'] },
    53:{ 'word3':'Jupiter-Conjunct-Vesta', 'cat': ['Love'] },
    54:{ 'word3':'Jupiter-Trine-Uranus', 'cat': ['Luck'] },
    55:{ 'word3':'Jupiter-Trine-Neptune', 'cat': ['Luck'] },
    56:{ 'word3':'Jupiter-Trine-Pluto', 'cat': ['Luck'] },
    57:{ 'word3':'Jupiter-Trine-Chiron', 'cat': ['Luck'] },
    58:{ 'word3':'Jupiter-Trine-Vesta', 'cat': ['Love'] },
    59:{ 'word3':'Jupiter-Quincunx-Uranus', 'cat': ['Luck'] },
    60:{ 'word3':'Jupiter-Quincunx-Neptune', 'cat': ['Luck'] },
    61:{ 'word3':'Jupiter-Quincunx-Pluto', 'cat': ['Luck'] },
    62:{ 'word3':'Jupiter-Quincunx-Chiron', 'cat': ['Luck'] },
    63:{ 'word3':'Jupiter-Quincunx-Vesta', 'cat': ['Love'] },
# URANUS - LUCK
    64:{ 'word3':'Uranus-Conjunct-Pluto', 'cat': ['Luck'] },
    65:{ 'word3':'Uranus-Conjunct-Chiron', 'cat': ['Luck'] },
    66:{ 'word3':'Uranus-Trine-Pluto', 'cat': ['Luck'] },
    67:{ 'word3':'Uranus-Trine-Chiron', 'cat': ['Luck'] },
    68:{ 'word3':'Uranus-Quincunx-Pluto', 'cat': ['Luck|b'] },
    69:{ 'word3':'Uranus-Quincunx-Chiron', 'cat': ['Luck'] },
# NEPTUNE - LUCK
    70:{ 'word3':'Neptune-Conjunct-Chiron', 'cat': ['Luck', 'Love'] },
    71:{ 'word3':'Neptune-Trine-Chiron', 'cat': ['Luck', 'Love'] },
    72:{ 'word3':'Neptune-Quincunx-Chiron', 'cat': ['Luck', 'Love'] },
# PLUTO - LUCK
    73:{ 'word3':'Pluto-Conjunct-Chiron', 'cat': ['Luck'] },
    74:{ 'word3':'Pluto-Trine-Chiron', 'cat': ['Luck'] },
    75:{ 'word3':'Pluto-Quincunx-Chiron', 'cat': ['Luck'] },
# SUN - LOVE
    76:{ 'word3':'Sun-Conjunct-Chiron', 'cat': ['Luck', 'Love|f'] },
    77:{},
    78:{},
# NEPTUNE - LOVE
    79:{},
    80:{},
    81:{},
# MOON - LOVE
    82:{ 'word3':'Moon-Conjunct-Venus', 'cat': ['Sex', 'Love|f'] },
    83:{ 'word3':'Moon-Conjunct-Chiron', 'cat': ['Love|f'] },
    84:{ 'word3':'Moon-Trine-Venus', 'cat': ['Sex', 'Love|f'] },
    85:{ 'word3':'Moon-Trine-Chiron', 'cat': ['Love|f'] },
    86:{ 'word3':'Moon-Quincunx-Venus', 'cat': ['Sex', 'Love|f'] },
    87:{ 'word3':'Moon-Quincunx-Chiron', 'cat': ['Love|f'] },
# VENUS - LOVE
    88:{},
    89:{},
    90:{},
    91:{ 'word3':'Venus-Conjunct-Vesta', 'cat': ['Love'] },
    92:{},
    93:{},
    94:{},
    95:{ 'word3':'Venus-Trine-Vesta', 'cat': ['Love'] },
    96:{},
    97:{},
    98:{},
    99:{ 'word3':'Venus-Quincunx-Vesta', 'cat': ['Love'] },
# SUN - LOVE / SEX
    100:{ 'word3':'Sun-Conjunct-Venus', 'cat': ['Sex', 'Love|f'] },
    101:{ 'word3':'Sun-Trine-Venus', 'cat': ['Sex', 'Love|f'] },
    102:{ 'word3':'Sun-Quincunx-Venus', 'cat': ['Sex', 'Love|f'] },
# VENUS - SEX
    103:{},
    104:{},
    105:{},
    106:{},
    107:{ 'word3':'Venus-Conjunct-Juno', 'cat': ['Sex'] },
    108:{},
    109:{},
    110:{},
    111:{},
    112:{ 'word3':'Venus-Trine-Juno', 'cat': ['Sex'] },
    113:{ 'word3':'Venus-Quincunx-Mars', 'cat': ['Sex'] },
    114:{},
    115:{},
    116:{},
    117:{ 'word3':'Venus-Quincunx-Juno', 'cat': ['Sex|b', 'Sex|m'] },
# VENUS - SEX - FEMALE
    118:{ 'word3':'Venus-Opposed-Mars', 'cat': ['Sex'] },
    119:{ 'word3':'Venus-Opposed-Pluto', 'cat': ['Sex'] },
    120:{ 'word3':'Venus-Sextile-Mars', 'cat': ['Sex'] },
    121:{ 'word3':'Venus-Sextile-Pluto', 'cat': ['Sex'] },
    122:{ 'word3':'Venus-Septile-Mars', 'cat': ['Sex'] },
    123:{ 'word3':'Venus-Septile-Pluto', 'cat': ['Sex'] },
    124:{ 'word3':'Venus-Square-Mars', 'cat': ['Sex'] },
    125:{ 'word3':'Venus-Square-Pluto', 'cat': ['Sex'] },
    126:{ 'word3':'Venus-Semisextile-Mars', 'cat': ['Sex'] },
    127:{ 'word3':'Venus-Semisextile-Pluto', 'cat': ['Sex'] },
    128:{ 'word3':'Venus-Quintile-Mars', 'cat': ['Sex|f'] },
    129:{ 'word3':'Venus-Quintile-Pluto', 'cat': ['Sex'] },
    130:{ 'word3':'Venus-Semiquintile-Mars', 'cat': ['Sex'] },
    131:{ 'word3':'Venus-Semiquintile-Pluto', 'cat': ['Sex'] },
    132:{ 'word3':'Venus-Biquintile-Mars', 'cat': ['Sex'] },
    133:{ 'word3':'Venus-Biquintile-Pluto', 'cat': ['Sex'] },
    134:{ 'word3':'Venus-Semisquare-Mars', 'cat': ['Sex'] },
    135:{ 'word3':'Venus-Semisquare-Pluto', 'cat': ['Sex'] },
    136:{ 'word3':'Venus-Sesquisquare-Mars', 'cat': ['Sex'] },
    137:{ 'word3':'Venus-Sesquisquare-Pluto', 'cat': ['Sex'] },
    138:{ 'word3':'Venus-Novile-Mars', 'cat': ['Sex'] },
    139:{ 'word3':'Venus-Novile-Pluto', 'cat': ['Sex'] },
    140:{},
# MARS - SEX
    141:{},
    142:{},
    143:{},
    144:{ 'word3':'Mars-Conjunct-Juno', 'cat': ['Sex'] },
    145:{},
    146:{},
    147:{},
    148:{},
    149:{ 'word3':'Mars-Trine-Juno', 'cat': ['Sex'] },
    150:{},
    151:{ 'word3':'Mars-Quincunx-Uranus', 'cat': ['Sex|m'] },
    152:{ 'word3':'Mars-Quincunx-Neptune', 'cat': ['Sex'] },
    153:{ 'word3':'Mars-Quincunx-Pluto', 'cat': ['Sex'] },
    154:{ 'word3':'Mars-Quincunx-Juno', 'cat': ['Sex'] },
    155:{ 'word3':'Mars-Quincunx-Chiron', 'cat': ['Sex'] },
    156:{ 'word3':'Mars-Opposed-Neptune', 'cat': ['Sex'] },
    157:{ 'word3':'Mars-Opposed-Uranus', 'cat': ['Sex|m', 'Drama'] },
    158:{ 'word3':'Mars-Opposed-Pluto', 'cat': ['Sex'] },
    159:{ 'word3':'Mars-Opposed-Chiron', 'cat': ['Sex'] },
    160:{ 'word3':'Mars-Square-Neptune', 'cat': ['Sex'] },
    161:{ 'word3':'Mars-Square-Uranus', 'cat': ['Sex|m', 'Drama'] },
    162:{ 'word3':'Mars-Square-Pluto', 'cat': ['Sex'] },
    163:{ 'word3':'Mars-Square-Chiron', 'cat': ['Sex'] },
    164:{ 'word3':'Mars-Semisquare-Neptune', 'cat': ['Sex'] },
    165:{ 'word3':'Mars-Semisquare-Uranus', 'cat': ['Sex|m', 'Drama'] },
    166:{ 'word3':'Mars-Semisquare-Pluto', 'cat': ['Sex'] },
    167:{ 'word3':'Mars-Semisquare-Chiron', 'cat': ['Sex'] },
    168:{ 'word3':'Mars-Sextile-Neptune', 'cat': ['Sex'] },
    169:{ 'word3':'Mars-Sextile-Uranus', 'cat': ['Sex|m', 'Drama'] },
    170:{ 'word3':'Mars-Sextile-Pluto', 'cat': ['Sex'] },
    171:{ 'word3':'Mars-Sextile-Chiron', 'cat': ['Sex'] },
    172:{ 'word3':'Mars-Septile-Neptune', 'cat': ['Sex'] },
    173:{ 'word3':'Mars-Septile-Uranus', 'cat': ['Sex|m', 'Drama'] },
    174:{ 'word3':'Mars-Septile-Pluto', 'cat': ['Sex'] },
    175:{ 'word3':'Mars-Septile-Chiron', 'cat': ['Sex'] },
    176:{ 'word3':'Mars-Semisextile-Neptune', 'cat': ['Sex'] },
    177:{ 'word3':'Mars-Semisextile-Uranus', 'cat': ['Sex|m', 'Drama'] },
    178:{ 'word3':'Mars-Semisextile-Pluto', 'cat': ['Sex'] },
    179:{ 'word3':'Mars-Semisextile-Chiron', 'cat': ['Sex'] },
    180:{ 'word3':'Mars-Quintile-Neptune', 'cat': ['Sex'] },
    181:{ 'word3':'Mars-Quintile-Uranus', 'cat': ['Sex|m', 'Drama'] },
    182:{ 'word3':'Mars-Quintile-Pluto', 'cat': ['Sex'] },
    183:{ 'word3':'Mars-Quintile-Chiron', 'cat': ['Sex',],  },
    184:{ 'word3':'Mars-Semiquintile-Neptune', 'cat': ['Sex'] },
    185:{ 'word3':'Mars-Semiquintile-Uranus', 'cat': ['Sex|m', 'Drama'] },
    186:{ 'word3':'Mars-Semiquintile-Pluto', 'cat': ['Sex'] },
    187:{ 'word3':'Mars-Semiquintile-Chiron', 'cat': ['Sex'] },
    188:{ 'word3':'Mars-Biquintile-Neptune', 'cat': ['Sex'] },
    189:{ 'word3':'Mars-Biquintile-Uranus', 'cat': ['Sex|m', 'Drama'] },
    190:{ 'word3':'Mars-Biquintile-Pluto', 'cat': ['Sex'] },
    191:{ 'word3':'Mars-Biquintile-Chiron', 'cat': ['Sex'] },
    192:{ 'word3':'Mars-Sesquisquare-Neptune', 'cat': ['Sex'] },
    193:{ 'word3':'Mars-Sesquisquare-Uranus', 'cat': ['Sex|m', 'Drama'] },
    194:{ 'word3':'Mars-Sesquisquare-Pluto', 'cat': ['Sex'] },
    195:{ 'word3':'Mars-Sesquisquare-Chiron', 'cat': ['Sex'] },
    196:{ 'word3':'Mars-Novile-Neptune', 'cat': ['Sex'] },
    197:{ 'word3':'Mars-Novile-Uranus', 'cat': ['Sex|m', 'Drama'] },
    198:{ 'word3':'Mars-Novile-Pluto', 'cat': ['Sex'] },
    199:{ 'word3':'Mars-Novile-Chiron', 'cat': ['Sex'] },
# PLUTO - SEX
    200:{ 'word3':'Pluto-Conjunct-Juno', 'cat': ['Sex'] },
    201:{ 'word3':'Pluto-Trine-Juno', 'cat': ['Sex'] },
    202:{ 'word3':'Pluto-Quincunx-Juno', 'cat': ['Sex'] },
# CHIRON - SEX
    203:{ 'word3':'Chiron-Conjunct-Juno', 'cat': ['Sex'] },
    204:{ 'word3':'Chiron-Trine-Juno', 'cat': ['Sex'] },
    205:{ 'word3':'Chiron-Quincunx-Juno', 'cat': ['Sex|b', 'Sex|m'] },
# SATURN - DRAMA - LUCK
    206:{ 'word3':'Saturn-Conjunct-Pluto', 'cat': ['Drama', 'Luck',] },
    207:{ 'word3':'Saturn-Trine-Pluto', 'cat': ['Drama', 'Luck', ] },
    208:{ 'word3':'Saturn-Quincunx-Pluto', 'cat': ['Drama', 'Luck'] },
# VENUS - DRAMA
    209:{ 'word3':'Venus-Opposed-Uranus', 'cat': ['Drama'] },
    210:{ 'word3':'Venus-Square-Uranus', 'cat': ['Drama'] },
    211:{ 'word3':'Venus-Semisquare-Uranus', 'cat': ['Drama'] },
    212:{ 'word3':'Venus-Sextile-Uranus', 'cat': ['Drama'] },
    213:{ 'word3':'Venus-Septile-Uranus', 'cat': ['Drama'] },
    214:{ 'word3':'Venus-Semisextile-Uranus', 'cat': ['Drama'] },
    215:{ 'word3':'Venus-Quintile-Uranus', 'cat': ['Drama'] },
    216:{ 'word3':'Venus-Semiquintile-Uranus', 'cat': ['Drama'] },
    217:{ 'word3':'Venus-Biquintile-Uranus', 'cat': ['Drama'] },
    218:{ 'word3':'Venus-Sesquisquare-Uranus', 'cat': ['Drama'] },
    219:{ 'word3':'Venus-Novile-Uranus', 'cat': ['Drama'] },
# MARS - DRAMA
    220:{},
    221:{},
    222:{},
    223:{},
    224:{},
    225:{},
    226:{},
    227:{},
    228:{},
    229:{},
    230:{},
    231:{},
# SATURN - DRAMA
    232:{ 'word3':'Saturn-Square-Neptune', 'cat': ['Drama',] },
# JUNO - DRAMA
    233:{ 'word3':'Juno-Conjunct-Sappho', 'cat': ['Drama'] },
    234:{ 'word3':'Juno-Trine-Sappho', 'cat': ['Drama'] },
    235:{ 'word3':'Juno-Quincunx-Sappho', 'cat': ['Drama'] },
    236:{ 'word3':'Juno-Square-Sappho', 'cat': ['Drama'] },
    237:{ 'word3':'Juno-Opposed-Sappho', 'cat': ['Drama'] },
# URANUS - DRAMA
    238:{ 'word3':'Uranus-Conjunct-Juno', 'cat': ['Drama'] },
    239:{ 'word3':'Uranus-Trine-Juno', 'cat': ['Drama'] },
    240:{ 'word3':'Uranus-Quincunx-Juno', 'cat': ['Drama'] },
    241:{ 'word3':'Uranus-Opposed-Pluto', 'cat': ['Drama'] },
    242:{ 'word3':'Uranus-Opposed-Juno', 'cat': ['Drama'] },
    243:{ 'word3':'Uranus-Opposed-Chiron', 'cat': ['Drama'] },
    244:{ 'word3':'Uranus-Square-Chiron', 'cat': ['Drama'] },
    245:{ 'word3':'Uranus-Square-Pluto', 'cat': ['Drama'] },
    246:{ 'word3':'Uranus-Square-Juno', 'cat': ['Drama'] },
    247:{ 'word3':'Uranus-Semisquare-Pluto', 'cat': ['Drama'] },
    248:{ 'word3':'Uranus-Semisquare-Juno', 'cat': ['Drama'] },
    249:{ 'word3':'Uranus-Sextile-Pluto', 'cat': ['Drama'] },
    250:{ 'word3':'Uranus-Sextile-Juno', 'cat': ['Drama'] },
    251:{ 'word3':'Uranus-Septile-Pluto', 'cat': ['Drama'] },
    252:{ 'word3':'Uranus-Septile-Juno', 'cat': ['Drama'] },
    253:{ 'word3':'Uranus-Semisextile-Pluto', 'cat': ['Drama'] },
    254:{ 'word3':'Uranus-Semisextile-Juno', 'cat': ['Drama'] },
    255:{ 'word3':'Uranus-Quintile-Pluto', 'cat': ['Drama'] },
    256:{ 'word3':'Uranus-Quintile-Juno', 'cat': ['Drama'] },
    257:{ 'word3':'Uranus-Semiquintile-Pluto', 'cat': ['Drama'] },
    258:{ 'word3':'Uranus-Semiquintile-Juno', 'cat': ['Drama'] },
    259:{ 'word3':'Uranus-Biquintile-Pluto', 'cat': ['Drama'] },
    260:{ 'word3':'Uranus-Biquintile-Juno', 'cat': ['Drama'] },
    261:{ 'word3':'Uranus-Sesquisquare-Pluto', 'cat': ['Drama'] },
    262:{ 'word3':'Uranus-Sesquisquare-Juno', 'cat': ['Drama'] },
    263:{ 'word3':'Uranus-Novile-Pluto', 'cat': ['Drama'] },
    264:{ 'word3':'Uranus-Novile-Juno', 'cat': ['Drama'] }
} # 0:{ 'word3':'', 'cat': ['...'] },



#-------------------------------------------------------

# import ASTROLOGYmagi as m
# m.AspectsDictSynastry
AspectsDictSynastry = {
    0: {},
# SUN - Luck
    1: {'word3': 'Sun-Conjunct-Chiron', 'cat': ['Luck', 'Love'] },
    2: {'word3': 'Sun-Trine-Chiron', 'cat': ['Luck', 'Love'] },
    3: {'word3': 'Sun-Quincunx-Chiron', 'cat': ['Luck', 'Love'] },
# VENUS - Luck
    4: {'word3': 'Venus-Conjunct-Chiron', 'cat': ['Luck', 'Love'] },
    5: {'word3': 'Venus-Trine-Chiron', 'cat': ['Luck', 'Love'] },
    6: {'word3': 'Venus-Quincunx-Chiron', 'cat': ['Luck', 'Love'] },
    7: {'word3': 'Venus-Conjunct-Pluto', 'cat': ['Luck', 'Love', 'Sex']},
    8: {'word3': 'Venus-Trine-Pluto', 'cat': ['Luck', 'Love', 'Sex']},
    9: {'word3': 'Venus-Quincunx-Pluto', 'cat': ['Luck', 'Love', 'Sex']},
    10: {'word3': 'Venus-Conjunct-Neptune', 'cat': ['Luck', 'Love']},
    11: {'word3': 'Venus-Trine-Neptune', 'cat': ['Luck', 'Love']},
    12: {'word3': 'Venus-Quincunx-Neptune', 'cat': ['Luck', 'Love']},
    13: {'word3': 'Venus-Conjunct-Uranus', 'cat': ['Luck']},
    14: {'word3': 'Venus-Trine-Uranus', 'cat': ['Luck']},
    15: {'word3': 'Venus-Quincunx-Uranus', 'cat': ['Luck']},
    16: {'word3': 'Venus-Conjunct-Jupiter', 'cat': ['Luck', 'Love']},
    17: {'word3': 'Venus-Trine-Jupiter', 'cat': ['Luck', 'Love']},
    18: {'word3': 'Venus-Quincunx-Jupiter', 'cat': ['Luck', 'Love']},
# JUPITER - Luck
    19: {'word3': 'Jupiter-Conjunct-Uranus', 'cat': ['Luck']},
    20: {'word3': 'Jupiter-Trine-Uranus', 'cat': ['Luck']},
    21: {'word3': 'Jupiter-Quincunx-Uranus', 'cat': ['Luck', 'Drama']},
    22: {'word3': 'Jupiter-Conjunct-Neptune', 'cat': ['Luck', 'Love']},
    23: {'word3': 'Jupiter-Trine-Neptune', 'cat': ['Luck', 'Love']},
    24: {'word3': 'Jupiter-Quincunx-Neptune', 'cat': ['Luck', 'Love']},
    25: {'word3': 'Jupiter-Conjunct-Pluto', 'cat': ['Luck']},
    26: {'word3': 'Jupiter-Trine-Pluto', 'cat': ['Luck']},
    27: {'word3': 'Jupiter-Quincunx-Pluto', 'cat': ['Luck']},
    28: {'word3': 'Jupiter-Conjunct-Chiron', 'cat': ['Luck', 'Love'] },
    29: {'word3': 'Jupiter-Trine-Chiron', 'cat': ['Luck', 'Love'] },
    30: {'word3': 'Jupiter-Quincunx-Chiron', 'cat': ['Luck', 'Love'] },
# NEPTUNE - Luck
    31: {'word3': 'Neptune-Conjunct-Chiron', 'cat': ['Luck', 'Love'] },
    32: {'word3': 'Neptune-Trine-Chiron', 'cat': ['Luck', 'Love'] },
    33: {'word3': 'Neptune-Quincunx-Chiron', 'cat': ['Luck', 'Love'] },
# URANUS - Luck
    34: {'word3': 'Uranus-Conjunct-Chiron', 'cat': ['Luck', 'Drama'] },
    35: {'word3': 'Uranus-Trine-Chiron', 'cat': ['Luck', 'Drama'] },
    36: {'word3': 'Uranus-Quincunx-Chiron', 'cat': ['Luck', 'Drama'] },
# PLUTO - Luck
    37: {'word3': 'Pluto-Conjunct-Chiron', 'cat': ['Luck', 'Love'] },
    38: {'word3': 'Pluto-Trine-Chiron', 'cat': ['Luck', 'Love'] },
    39: {'word3': 'Pluto-Quincunx-Chiron', 'cat': ['Luck', 'Love'] },
# SUN - Love
    40: {'word3': 'Sun-Conjunct-Venus', 'cat': ['Love'] },
    41: {'word3': 'Sun-Trine-Venus', 'cat': ['Love'] },
    42: {'word3': 'Sun-Quincunx-Venus', 'cat': ['Love'] },
    43: {'word3': 'Sun-Conjunct-Moon', 'cat': ['Love'] },
    44: {'word3': 'Sun-Trine-Moon', 'cat': ['Love'] },
    45: {'word3': 'Sun-Quincunx-Moon', 'cat': ['Love'] },
    46: {},
    47: {'word3': 'Sun-Quincunx-Neptune', 'cat': ['Love']},
    48: {'word3': 'Sun-Trine-Jupiter', 'cat': ['Love']},
# MOON - Love
    49: {'word3': 'Moon-Conjunct-Venus', 'cat': ['Love'] },
    50: {'word3': 'Moon-Trine-Venus', 'cat': ['Love'] },
    51: {'word3': 'Moon-Quincunx-Venus', 'cat': ['Love'] },
    52: {'word3': 'Moon-Conjunct-Jupiter', 'cat': ['Love'] },
    53: {'word3': 'Moon-Conjunct-Chiron', 'cat': ['Love']},
    54: {'word3': 'Moon-Trine-Chiron', 'cat': ['Love']},
    55: {'word3': 'Moon-Quincunx-Chiron', 'cat': ['Love']},
# MERCURY - Love
    56: {'word3': 'Mercury-Conjunct-Neptune', 'cat': ['Love'] },
    57: {'word3': 'Mercury-Trine-Neptune', 'cat': ['Love'] },
    58: {'word3': 'Mercury-Quincunx-Neptune', 'cat': ['Love'] },
    59: {'word3': 'Mercury-Conjunct-Chiron', 'cat': ['Love']},
    60: {'word3': 'Mercury-Trine-Chiron', 'cat': ['Love']},
    61: {'word3': 'Mercury-Quincunx-Chiron', 'cat': ['Love']},
# VENUS - Love
    62: {'word3': 'Venus-Semisextile-Pluto', 'cat': ['Love']},
    63: {'word3': 'Venus-Sextile-Pluto', 'cat': ['Love']},
    64: {'word3': 'Venus-Square-Pluto', 'cat': ['Love', 'Drama']},
    65: {'word3': 'Venus-Opposed-Pluto', 'cat': ['Love', 'Drama']},
# MARS - Love (some sex)
    66: {'word3': 'Mars-Conjunct-Chiron', 'cat': ['Love', 'Sex'] },
    67: {'word3': 'Mars-Trine-Chiron', 'cat': ['Love', 'Sex']},
    68: {'word3': 'Mars-Quincunx-Chiron', 'cat': ['Love', 'Sex']},
    69: {'word3': 'Mars-Semisextile-Pluto', 'cat': ['Love']},
    70: {'word3': 'Mars-Sextile-Pluto', 'cat': ['Love']},
    71: {'word3': 'Mars-Square-Pluto', 'cat': ['Love']},
    72: {'word3': 'Mars-Opposed-Pluto', 'cat': ['Love']},
    73: {'word3': 'Mars-Quincunx-Pluto', 'cat': ['Love', 'Sex']},
# CHIRON - Love
    74: {'word3': 'Chiron-Conjunct-Juno', 'cat': ['Love', 'Sex'] },
    75: {'word3': 'Chiron-Trine-Juno', 'cat': ['Love', 'Sex'] },
    76: {'word3': 'Chiron-Quincunx-Juno', 'cat': ['Love', 'Sex'] },
    77: {'word3': 'Chiron-Conjunct-Chiron', 'cat': ['Love'] },
    78: {'word3': 'Chiron-Conjunct-Ceres', 'cat': ['Love'] },
    79: {'word3': 'Chiron-Conjunct-Pallas', 'cat': ['Love'] },
    80: {'word3': 'Chiron-Conjunct-Vesta', 'cat': ['Love'] },
    81: {'word3': 'Chiron-Conjunct-Eros', 'cat': ['Love'] },
    82: {'word3': 'Chiron-Conjunct-Amor', 'cat': ['Love'] },
    83: {'word3': 'Chiron-Conjunct-Sappho', 'cat': ['Love'] },
    84: {'word3': 'Chiron-Conjunct-Lilith', 'cat': ['Love'] },
    85: {'word3': 'Chiron-Trine-Chiron', 'cat': ['Love'] },
    86: {'word3': 'Chiron-Trine-Ceres', 'cat': ['Love'] },
    87: {'word3': 'Chiron-Trine-Pallas', 'cat': ['Love'] },
    88: {'word3': 'Chiron-Trine-Vesta', 'cat': ['Love'] },
    89: {'word3': 'Chiron-Trine-Eros', 'cat': ['Love'] },
    90: {'word3': 'Chiron-Trine-Amor', 'cat': ['Love'] },
    91: {'word3': 'Chiron-Trine-Sappho', 'cat': ['Love'] },
    92: {'word3': 'Chiron-Trine-Lilith', 'cat': ['Love'] },
    93: {'word3': 'Chiron-Quincunx-Chiron', 'cat': ['Love'] },
    94: {'word3': 'Chiron-Quincunx-Ceres', 'cat': ['Love'] },
    95: {'word3': 'Chiron-Quincunx-Pallas', 'cat': ['Love'] },
    96: {'word3': 'Chiron-Quincunx-Vesta', 'cat': ['Love'] },
    97: {'word3': 'Chiron-Quincunx-Eros', 'cat': ['Love'] },
    98: {'word3': 'Chiron-Quincunx-Amor', 'cat': ['Love'] },
    99: {'word3': 'Chiron-Quincunx-Sappho', 'cat': ['Love'] },
    100: {'word3': 'Chiron-Quincunx-Lilith', 'cat': ['Love'] },
# NORTHNODE - SOUTHNODE - Love
    101: {'word3': 'NorthNode-Conjunct-Chiron', 'cat': ['Love']},
    102: {'word3': 'NorthNode-Trine-Chiron', 'cat': ['Love']},
    103: {'word3': 'NorthNode-Quincunx-Chiron', 'cat': ['Love']},
    104: {'word3': 'SouthNode-Conjunct-Chiron', 'cat': ['Love']},
    105: {'word3': 'SouthNode-Trine-Chiron', 'cat': ['Love']},
    106: {'word3': 'SouthNode-Quincunx-Chiron', 'cat': ['Love']},
# SUN - Sex
    107: {'word3': 'Sun-Conjunct-Mars', 'cat': ['Sex', 'Drama'] },
    108: {'word3': 'Sun-Trine-Mars', 'cat': ['Sex', 'Drama'] },
    109: {'word3': 'Sun-Quincunx-Mars', 'cat': ['Sex', 'Drama'] },
    110: {'word3': 'Sun-Conjunct-Pluto', 'cat': ['Sex'] },
    111: {'word3': 'Sun-Trine-Pluto', 'cat': ['Sex'] },
    112: {'word3': 'Sun-Quincunx-Pluto', 'cat': ['Sex'] },
    113: {'word3': 'Sun-Conjunct-Juno', 'cat': ['Sex']},
    114: {'word3': 'Sun-Trine-Juno', 'cat': ['Sex']},
    115: {'word3': 'Sun-Quincunx-Juno', 'cat': ['Sex']},
# MOON - Sex
    116: {'word3': 'Moon-Conjunct-Juno', 'cat': ['Sex']},
    117: {'word3': 'Moon-Trine-Juno', 'cat': ['Sex']},
    118: {'word3': 'Moon-Quincunx-Juno', 'cat': ['Sex']},
# MERCURY - Sex
    119: {'word3': 'Mercury-Conjunct-Juno', 'cat': ['Sex']},
    120: {'word3': 'Mercury-Trine-Juno', 'cat': ['Sex']},
    121: {'word3': 'Mercury-Quincunx-Juno', 'cat': ['Sex']},
# VENUS - Sex
    122: {'word3': 'Venus-Conjunct-Mars', 'cat': ['Sex'] },
    123: {'word3': 'Venus-Trine-Mars', 'cat': ['Sex'] },
    124: {'word3': 'Venus-Quincunx-Mars', 'cat': ['Sex'] },
    125: {'word3': 'Venus-Conjunct-Juno', 'cat': ['Sex']},
    126: {'word3': 'Venus-Trine-Juno', 'cat': ['Sex'] },
    127: {'word3': 'Venus-Quincunx-Juno', 'cat': ['Sex'] },
    128: {},
    129: {},
# MARS - Sex
    130: {'word3': 'Mars-Conjunct-Uranus', 'cat': ['Sex'] },
    131: {'word3': 'Mars-Trine-Uranus', 'cat': ['Sex'] },
    132: {'word3': 'Mars-Quincunx-Uranus', 'cat': ['Sex'] },
    133: {'word3': 'Mars-Trine-Pluto', 'cat': ['Sex'] },
    134: {'word3': 'Mars-Conjunct-Pluto', 'cat': ['Sex'] },
    135: {'word3': 'Mars-Conjunct-Juno', 'cat': ['Sex'] },
    136: {'word3': 'Mars-Trine-Juno', 'cat': ['Sex']},
    137: {'word3': 'Mars-Quincunx-Juno', 'cat': ['Sex']},
# JUPITER - Sex
    138: {'word3': 'Jupiter-Conjunct-Juno', 'cat': ['Sex'] },
    139: {'word3': 'Jupiter-Trine-Juno', 'cat': ['Sex']},
    140: {'word3': 'Jupiter-Quincunx-Juno', 'cat': ['Sex']},
# SATURN - Sex
    141: {'word3': 'Saturn-Conjunct-Juno', 'cat': ['Sex'] },
    142: {'word3': 'Saturn-Trine-Juno', 'cat': ['Sex']},
# URANUS - Sex
    143: {'word3': 'Uranus-Conjunct-Juno', 'cat': ['Sex'] },
    144: {'word3': 'Uranus-Trine-Juno', 'cat': ['Sex']},
    145: {'word3': 'Uranus-Quincunx-Juno', 'cat': ['Sex']},
# NEPTUNE - Sex
    146: {'word3': 'Neptune-Conjunct-Juno', 'cat': ['Sex'] },
    147: {'word3': 'Neptune-Trine-Juno', 'cat': ['Sex']},
    148: {'word3': 'Neptune-Quincunx-Juno', 'cat': ['Sex']},
# PLUTO - Sex
    149: {'word3': 'Pluto-Conjunct-Juno', 'cat': ['Sex'] },
    150: {'word3': 'Pluto-Trine-Juno', 'cat': ['Sex']},
    151: {'word3': 'Pluto-Quincunx-Juno', 'cat': ['Sex']},
# JUNO - Sex
    152: {'word3': 'Juno-Conjunct-Juno', 'cat': ['Sex']},
    153: {'word3': 'Juno-Conjunct-Vesta', 'cat': ['Sex']},
    154: {'word3': 'Juno-Conjunct-Eros', 'cat': ['Sex']},
    155: {'word3': 'Juno-Conjunct-Amor', 'cat': ['Sex']},
    156: {'word3': 'Juno-Conjunct-Sappho', 'cat': ['Sex']},
    157: {'word3': 'Juno-Conjunct-Lilith', 'cat': ['Sex']},
    158: {'word3': 'Juno-Trine-Juno', 'cat': ['Sex']},
    159: {'word3': 'Juno-Trine-Vesta', 'cat': ['Sex']},
    160: {'word3': 'Juno-Trine-Eros', 'cat': ['Sex']},
    161: {'word3': 'Juno-Trine-Amor', 'cat': ['Sex']},
    162: {'word3': 'Juno-Trine-Sappho', 'cat': ['Sex']},
    163: {'word3': 'Juno-Trine-Lilith', 'cat': ['Sex']},
    164: {'word3': 'Juno-Quincunx-Juno', 'cat': ['Sex']},
    165: {'word3': 'Juno-Quincunx-Vesta', 'cat': ['Sex']},
    166: {'word3': 'Juno-Quincunx-Eros', 'cat': ['Sex']},
    167: {'word3': 'Juno-Quincunx-Amor', 'cat': ['Sex']},
    168: {'word3': 'Juno-Quincunx-Sappho', 'cat': ['Sex']},
    169: {'word3': 'Juno-Quincunx-Lilith', 'cat': ['Sex']},
# NORTHNODE - SOUTHNODE - Sex
    170: {'word3': 'NorthNode-Conjunct-Juno', 'cat': ['Sex'] },
    171: {'word3': 'NorthNode-Trine-Juno', 'cat': ['Sex']},
    172: {'word3': 'NorthNode-Quincunx-Juno', 'cat': ['Sex']},
    173: {'word3': 'SouthNode-Conjunct-Juno', 'cat': ['Sex'] },
    174: {'word3': 'SouthNode-Trine-Juno', 'cat': ['Sex']},
    175: {'word3': 'SouthNode-Quincunx-Juno', 'cat': ['Sex']},
# CERES - Sex
    176: {'word3': 'Ceres-Conjunct-Juno', 'cat': ['Sex'] },
    177: {'word3': 'Ceres-Trine-Juno', 'cat': ['Sex'] },
    178: {'word3': 'Ceres-Quincunx-Juno', 'cat': ['Sex']},
# PALLAS - Sex
    179: {'word3': 'Pallas-Conjunct-Juno', 'cat': ['Sex'] },
    180: {'word3': 'Pallas-Trine-Juno', 'cat': ['Sex'] },
    181: {'word3': 'Pallas-Quincunx-Juno', 'cat': ['Sex']},
# SUN - Drama
    182: {'word3': 'Sun-Conjunct-Saturn', 'cat': ['Drama']},
    183: {'word3': 'Sun-Trine-Saturn', 'cat': ['Drama']},
    184: {'word3': 'Sun-Quincunx-Saturn', 'cat': ['Drama']},
    185: {'word3': 'Sun-Opposed-Chiron', 'cat': ['Drama'] },
    186: {'word3': 'Sun-Square-Pluto', 'cat': ['Drama']},
    187: {'word3': 'Sun-Square-Chiron', 'cat': ['Drama'] },
    188: {'word3': 'Sun-Semisquare-Chiron', 'cat': ['Drama'] },
    189: {'word3': 'Sun-Conjunct-SaturnChironMidpoint', 'cat': ['Drama']},
    190: {'word3': 'Sun-Trine-SaturnChironMidpoint', 'cat': ['Drama']},
    191: {'word3': 'Sun-Quincunx-SaturnChironMidpoint', 'cat': ['Drama']},
# MOON - Drama
    192: {'word3': 'Moon-Opposed-Chiron', 'cat': ['Drama'] },
    193: {'word3': 'Moon-Square-Chiron', 'cat': ['Drama'] },
    194: {'word3': 'Moon-Semisquare-Chiron', 'cat': ['Drama'] },
    195: {'word3': 'Moon-Conjunct-SaturnChironMidpoint', 'cat': ['Drama']},
# MERCURY - Drama
    196: {'word3': 'Mercury-Conjunct-SaturnChironMidpoint', 'cat': ['Drama']},
    197: {'word3': 'Mercury-Opposed-Chiron', 'cat': ['Drama'] },
    198: {'word3': 'Mercury-Square-Chiron', 'cat': ['Drama'] },
    199: {'word3': 'Mercury-Semisquare-Chiron', 'cat': ['Drama'] },
# VENUS - Drama
    200: {'word3': 'Venus-Conjunct-Saturn', 'cat': ['Drama']},
    201: {'word3': 'Venus-Trine-Saturn', 'cat': ['Drama']},
    202: {'word3': 'Venus-Quincunx-Saturn', 'cat': ['Drama']},
    203: {'word3': 'Venus-Opposed-Neptune', 'cat': ['Drama'] },
    204: {'word3': 'Venus-Opposed-Chiron', 'cat': ['Drama'] },
    205: {'word3': 'Venus-Square-Venus', 'cat': ['Drama'] },
    206: {'word3': 'Venus-Square-Neptune', 'cat': ['Drama'] },
    207: {'word3': 'Venus-Square-Chiron', 'cat': ['Drama'] },
    208: {'word3': 'Venus-Semisquare-Chiron', 'cat': ['Drama']},
    209: {'word3': 'Venus-Conjunct-SaturnChironMidpoint', 'cat': ['Drama']},
    210: {'word3': 'Venus-Trine-SaturnChironMidpoint', 'cat': ['Drama']},
    211: {'word3': 'Venus-Quincunx-SaturnChironMidpoint', 'cat': ['Drama']},
# MARS - Drama
    212: {'word3': 'Mars-Opposed-Neptune', 'cat': ['Drama'] },
    213: {'word3': 'Mars-Opposed-Chiron', 'cat': ['Drama'] },
    214: {'word3': 'Mars-Square-Neptune', 'cat': ['Drama'] },
    215: {'word3': 'Mars-Square-Chiron', 'cat': ['Drama'] },
    216: {'word3': 'Mars-Square-Saturn', 'cat': ['Drama']},
    217: {'word3': 'Mars-Semisquare-Chiron', 'cat': ['Drama']},
    218: {'word3': 'Mars-Conjunct-SaturnChironMidpoint', 'cat': ['Drama']},
# JUPITER - Drama
    219: {'word3': 'Jupiter-Conjunct-Saturn', 'cat': ['Drama']},
    220: {'word3': 'Jupiter-Trine-Saturn', 'cat': ['Drama']},
    221: {'word3': 'Jupiter-Quincunx-Saturn', 'cat': ['Drama']},
    222: {'word3': 'Jupiter-Opposed-Saturn', 'cat': ['Drama'] },
    223: {'word3': 'Jupiter-Opposed-Uranus', 'cat': ['Drama'] },
    224: {'word3': 'Jupiter-Opposed-Chiron', 'cat': ['Drama'] },
    225: {'word3': 'Jupiter-Square-Chiron', 'cat': ['Drama'] },
    226: {'word3': 'Jupiter-Square-Saturn', 'cat': ['Drama'] },
    227: {'word3': 'Jupiter-Square-Uranus', 'cat': ['Drama'] },
    228: {'word3': 'Jupiter-Semisquare-Chiron', 'cat': ['Drama']},
    229: {'word3': 'Jupiter-Conjunct-SaturnChironMidpoint', 'cat': ['Drama']},
    230: {'word3': 'Jupiter-Trine-SaturnChironMidpoint', 'cat': ['Drama']},
    231: {'word3': 'Jupiter-Quincunx-SaturnChironMidpoint', 'cat': ['Drama']},
# SATURN - Drama
    232: {'word3': 'Saturn-Conjunct-Neptune', 'cat': ['Drama']},
    233: {'word3': 'Saturn-Conjunct-Chiron', 'cat': ['Drama']},
    234: {'word3': 'Saturn-Trine-Neptune', 'cat': ['Drama']},
    235: {'word3': 'Saturn-Trine-Chiron', 'cat': ['Drama']},
    236: {'word3': 'Saturn-Quincunx-Neptune', 'cat': ['Drama']},
    237: {'word3': 'Saturn-Quincunx-Pluto', 'cat': ['Drama']},
    238: {'word3': 'Saturn-Quincunx-Chiron', 'cat': ['Drama']},
    239: {'word3': 'Saturn-Opposed-Pluto', 'cat': ['Drama']},
    240: {'word3': 'Saturn-Opposed-Chiron', 'cat': ['Drama'] },
    241: {'word3': 'Saturn-Square-Neptune', 'cat': ['Drama']},
    242: {'word3': 'Saturn-Square-Pluto', 'cat': ['Drama']},
    243: {'word3': 'Saturn-Square-Chiron', 'cat': ['Drama']},
    244: {'word3': 'Saturn-Semisquare-Chiron', 'cat': ['Drama']},
    245: {'word3': 'Saturn-Conjunct-SaturnChironMidpoint', 'cat': ['Drama']},
    246: {'word3': 'SaturnChironMidpoint-Square-Chiron', 'cat': ['Drama']},
    247: {'word3': 'SaturnChironMidpoint-Opposed-Chiron', 'cat': ['Drama']},
    248: {'word3': 'SaturnChironMidpoint-Quincunx-Chiron', 'cat': ['Drama']},
# NEPTUNE - Drama
    249: {'word3': 'Neptune-Conjunct-SaturnChironMidpoint', 'cat': ['Drama'] },
    250: {'word3': 'Neptune-Trine-SaturnChironMidpoint', 'cat': ['Drama'] },
    251: {'word3': 'Neptune-Quincunx-SaturnChironMidpoint', 'cat': ['Drama'] },
    252: {'word3': 'Neptune-Opposed-Chiron', 'cat': ['Drama']},
    253: {'word3': 'Neptune-Opposed-Midheaven', 'cat': ['Drama'] },
    254: {'word3': 'Neptune-Square-Chiron', 'cat': ['Drama'] },
    255: {'word3': 'Neptune-Square-Midheaven', 'cat': ['Drama'] },
    256: {'word3': 'Neptune-Semisquare-Chiron', 'cat': ['Drama']},
# URANUS - Drama
    257: {'word3': 'Uranus-Opposed-Chiron', 'cat': ['Drama'] },
    258: {'word3': 'Uranus-Square-Chiron', 'cat': ['Drama'] },
    259: {'word3': 'Uranus-Semisquare-Chiron', 'cat': ['Drama']},
    260: {'word3': 'Uranus-Conjunct-SaturnChironMidpoint', 'cat': ['Drama']},
# PLUTO - Drama
    261: {'word3': 'Pluto-Semisquare-Chiron', 'cat': ['Drama']},
    262: {'word3': 'Pluto-Opposed-Chiron', 'cat': ['Drama'] },
    263: {'word3': 'Pluto-Square-Chiron', 'cat': ['Drama'] },
    264: {'word3': 'Pluto-Conjunct-SaturnChironMidpoint', 'cat': ['Drama']},
# NORTHNODE - SOUTHNODE - Drama
    265: {'word3': 'NorthNode-Opposed-Chiron', 'cat': ['Drama'] },
    266: {'word3': 'NorthNode-Square-Chiron', 'cat': ['Drama'] },
    267: {'word3': 'NorthNode-Semisquare-Chiron', 'cat': ['Drama']},
    268: {'word3': 'SouthNode-Opposed-Chiron', 'cat': ['Drama'] },
    269: {'word3': 'SouthNode-Square-Chiron', 'cat': ['Drama'] },
    270: {'word3': 'SouthNode-Semisquare-Chiron', 'cat': ['Drama']},
# CHIRON - Drama
    271: {'word3': 'Chiron-Opposed-Chiron', 'cat': ['Drama'] },
    272: {'word3': 'Chiron-Opposed-Ceres', 'cat': ['Drama'] },
    273: {'word3': 'Chiron-Opposed-Pallas', 'cat': ['Drama'] },
    274: {'word3': 'Chiron-Opposed-Vesta', 'cat': ['Drama'] },
    275: {'word3': 'Chiron-Opposed-Eros', 'cat': ['Drama'] },
    276: {'word3': 'Chiron-Opposed-Amor', 'cat': ['Drama'] },
    277: {'word3': 'Chiron-Opposed-Sappho', 'cat': ['Drama'] },
    278: {'word3': 'Chiron-Opposed-Lilith', 'cat': ['Drama'] },
    279: {'word3': 'Chiron-Square-Chiron', 'cat': ['Drama'] },
    280: {'word3': 'Chiron-Square-Ceres', 'cat': ['Drama'] },
    281: {'word3': 'Chiron-Square-Pallas', 'cat': ['Drama'] },
    282: {'word3': 'Chiron-Square-Vesta', 'cat': ['Drama'] },
    283: {'word3': 'Chiron-Square-Eros', 'cat': ['Drama'] },
    284: {'word3': 'Chiron-Square-Amor', 'cat': ['Drama'] },
    285: {'word3': 'Chiron-Square-Sappho', 'cat': ['Drama'] },
    286: {'word3': 'Chiron-Square-Lilith', 'cat': ['Drama'] },
    287: {'word3': 'Chiron-Semisquare-Chiron', 'cat': ['Drama'] },
    288: {'word3': 'Chiron-Semisquare-Ceres', 'cat': ['Drama'] },
    289: {'word3': 'Chiron-Semisquare-Pallas', 'cat': ['Drama'] },
    290: {'word3': 'Chiron-Semisquare-Vesta', 'cat': ['Drama'] },
    291: {'word3': 'Chiron-Semisquare-Eros', 'cat': ['Drama'] },
    292: {'word3': 'Chiron-Semisquare-Amor', 'cat': ['Drama'] },
    293: {'word3': 'Chiron-Semisquare-Sappho', 'cat': ['Drama'] },
    294: {'word3': 'Chiron-Semisquare-Lilith', 'cat': ['Drama'] },
    295: {'word3': 'Chiron-Conjunct-SaturnChironMidpoint', 'cat': ['Drama'] },
    296: {'word3': 'Chiron-Trine-SaturnChironMidpoint', 'cat': ['Drama'] },
    297: {'word3': 'Chiron-Quincunx-SaturnChironMidpoint', 'cat': ['Drama'] },
# ASTERIODS - Drama
    298: {'word3': 'Ceres-Conjunct-SaturnChironMidpoint', 'cat': ['Drama'] },
    299: {'word3': 'Pallas-Conjunct-SaturnChironMidpoint', 'cat': ['Drama'] },
    300: {'word3': 'Juno-Conjunct-SaturnChironMidpoint', 'cat': ['Drama'] },
    301: {'word3': 'Vesta-Conjunct-SaturnChironMidpoint', 'cat': ['Drama'] },
    302: {'word3': 'Eros-Conjunct-SaturnChironMidpoint', 'cat': ['Drama'] },
    303: {'word3': 'Amor-Conjunct-SaturnChironMidpoint', 'cat': ['Drama'] },
    304: {'word3': 'Sappho-Conjunct-SaturnChironMidpoint', 'cat': ['Drama'] },
    305: {'word3': 'Lilith-Conjunct-SaturnChironMidpoint', 'cat': ['Drama'] }
} # ... For Later: too high of sex is bad


#---------------------------------------------



magiPlanetsFinancial1 = {
    0: "Venus",
    1: "Neptune",
    2: "Pluto",
    3: "Chiron",
    4: "Ceres",
    5: "Sedna",
    6: "Odin",
    7: "Midas",
    8: "Quaoar",
    9: "ErisUB313"
}



#---------------------------

# import ASTROLOGYmagi as m
# m.magiAspectsFinancial
magiAspectsFinancial = {
    # the money
    0: {'word3': 'Venus-Conjunct-Neptune', 'cat': ['Money']},
    1: {'word3': 'Venus-Trine-Neptune', 'cat': ['Money']},
    2: {'word3': 'Venus-Quincunx-Neptune', 'cat': ['Money']},
    3: {'word3': 'Venus-Parallel-Neptune', 'cat': ['Money']},
    4: {'word3': 'Venus-Contraparallel-Neptune', 'cat': ['Money']},
    5: {'word3': 'Venus-Conjunt-Pluto', 'cat': ['Money']},
    6: {'word3': 'Venus-Trine-Pluto', 'cat': ['Money']},
    7: {'word3': 'Venus-Quincunx-Pluto', 'cat': ['Money']},
    8: {'word3': 'Venus-Parallel-Pluto', 'cat': ['Money']},
    3: {'word3': 'Venus-Contraparallel-Pluto', 'cat': ['Money']},
    9: {'word3': 'Venus-Conjunct-Chiron', 'cat': ['Money']},
    10: {'word3': 'Venus-Trine-Chiron', 'cat': ['Money']},
    11: {'word3': 'Venus-Quincunx-Chiron', 'cat': ['Money']},
    12: {'word3': 'Venus-Parallel-Chiron', 'cat': ['Money']},
    13: {'word3': 'Venus-Contraparallel-Chiron', 'cat': ['Money']},
    14: {'word3': 'Venus-Conjunct-Ceres', 'cat': ['Money']},
    15: {'word3': 'Venus-Trine-Ceres', 'cat': ['Money']},
    16: {'word3': 'Venus-Quincunx-Ceres', 'cat': ['Money']},
    17: {'word3': 'Venus-Parallel-Ceres', 'cat': ['Money']},
    18: {'word3': 'Venus-Contraparallel-Ceres', 'cat': ['Money']},
    19: {'word3': 'Venus-Conjunct-Sedna', 'cat': ['Money']},
    20: {'word3': 'Venus-Trine-Sedna', 'cat': ['Money']},
    21: {'word3': 'Venus-Quincunx-Sedna', 'cat': ['Money']},
    22: {'word3': 'Venus-Parallel-Sedna', 'cat': ['Money']},
    23: {'word3': 'Venus-Contraparallel-Sedna', 'cat': ['Money']},
    24: {'word3': 'Venus-Conjunct-Odin', 'cat': ['Money']},
    25: {'word3': 'Venus-Trine-Odin', 'cat': ['Money']},
    26: {'word3': 'Venus-Quincunx-Odin', 'cat': ['Money']},
    27: {'word3': 'Venus-Parallel-Odin', 'cat': ['Money']},
    28: {'word3': 'Venus-Contraparallel-Odin', 'cat': ['Money']},
    29: {'word3': 'Venus-Conjunct-Midas', 'cat': ['Money']},
    30: {'word3': 'Venus-Trine-Midas', 'cat': ['Money']},
    31: {'word3': 'Venus-Quincunx-Midas', 'cat': ['Money']},
    32: {'word3': 'Venus-Parallel-Midas', 'cat': ['Money']},
    33: {'word3': 'Venus-Contraparallel-Midas', 'cat': ['Money']},
    34: {'word3': 'Venus-Conjunct-Quaoar', 'cat': ['Money']},
    35: {'word3': 'Venus-Trine-Quaoar', 'cat': ['Money']},
    36: {'word3': 'Venus-Quincunx-Quaoar', 'cat': ['Money']},
    37: {'word3': 'Venus-Parallel-Quaoar', 'cat': ['Money']},
    38: {'word3': 'Venus-Contraparallel-Quaoar', 'cat': ['Money']},
    39: {'word3': 'Venus-Conjunct-ErisUB313', 'cat': ['Money']},
    40: {'word3': 'Venus-Trine-ErisUB313', 'cat': ['Money']},
    41: {'word3': 'Venus-Quincunx-ErisUB313', 'cat': ['Money']},
    42: {'word3': 'Venus-Parallel-ErisUB313', 'cat': ['Money']},
    43: {'word3': 'Venus-Contraparallel-ErisUB313', 'cat': ['Money']},
    44: {'word3': 'Neptune-Conjunt-Pluto', 'cat': ['Money']},
    45: {'word3': 'Neptune-Trine-Pluto', 'cat': ['Money']},
    46: {'word3': 'Neptune-Quincunx-Pluto', 'cat': ['Money']},
    47: {'word3': 'Neptune-Parallel-Pluto', 'cat': ['Money']},
    48: {'word3': 'Neptune-Contraparallel-Pluto', 'cat': ['Money']},
    49: {'word3': 'Neptune-Conjunct-Chiron', 'cat': ['Money']},
    50: {'word3': 'Neptune-Trine-Chiron', 'cat': ['Money']},
    51: {'word3': 'Neptune-Quincunx-Chiron', 'cat': ['Money']},
    52: {'word3': 'Neptune-Parallel-Chiron', 'cat': ['Money']},
    53: {'word3': 'Neptune-Contraparallel-Chiron', 'cat': ['Money']},
    54: {'word3': 'Neptune-Conjunct-Ceres', 'cat': ['Money']},
    55: {'word3': 'Neptune-Trine-Ceres', 'cat': ['Money']},
    56: {'word3': 'Neptune-Quincunx-Ceres', 'cat': ['Money']},
    57: {'word3': 'Neptune-Parallel-Ceres', 'cat': ['Money']},
    58: {'word3': 'Neptune-Contraparallel-Ceres', 'cat': ['Money']},
    59: {'word3': 'Neptune-Conjunct-Sedna', 'cat': ['Money']},
    60: {'word3': 'Neptune-Trine-Sedna', 'cat': ['Money']},
    61: {'word3': 'Neptune-Quincunx-Sedna', 'cat': ['Money']},
    62: {'word3': 'Neptune-Parallel-Sedna', 'cat': ['Money']},
    63: {'word3': 'Neptune-Contraparallel-Sedna', 'cat': ['Money']},
    64: {'word3': 'Neptune-Conjunct-Odin', 'cat': ['Money']},
    65: {'word3': 'Neptune-Trine-Odin', 'cat': ['Money']},
    66: {'word3': 'Neptune-Quincunx-Odin', 'cat': ['Money']},
    67: {'word3': 'Neptune-Parallel-Odin', 'cat': ['Money']},
    68: {'word3': 'Neptune-Contraparallel-Odin', 'cat': ['Money']},
    69: {'word3': 'Neptune-Conjunct-Midas', 'cat': ['Money']},
    70: {'word3': 'Neptune-Trine-Midas', 'cat': ['Money']},
    71: {'word3': 'Neptune-Quincunx-Midas', 'cat': ['Money']},
    72: {'word3': 'Neptune-Parallel-Midas', 'cat': ['Money']},
    73: {'word3': 'Neptune-Contraparallel-Midas', 'cat': ['Money']},
    74: {'word3': 'Neptune-Conjunct-Quaoar', 'cat': ['Money']},
    75: {'word3': 'Neptune-Trine-Quaoar', 'cat': ['Money']},
    76: {'word3': 'Neptune-Quincunx-Quaoar', 'cat': ['Money']},
    77: {'word3': 'Neptune-Parallel-Quaoar', 'cat': ['Money']},
    78: {'word3': 'Neptune-Contraparallel-Quaoar', 'cat': ['Money']},
    79: {'word3': 'Neptune-Conjunct-ErisUB313', 'cat': ['Money']},
    80: {'word3': 'Neptune-Trine-ErisUB313', 'cat': ['Money']},
    81: {'word3': 'Neptune-Quincunx-ErisUB313', 'cat': ['Money']},
    82: {'word3': 'Neptune-Parallel-ErisUB313', 'cat': ['Money']},
    83: {'word3': 'Neptune-Contraparallel-ErisUB313', 'cat': ['Money']},
    84: {'word3': 'Pluto-Conjunct-Chiron', 'cat': ['Money']},
    85: {'word3': 'Pluto-Trine-Chiron', 'cat': ['Money']},
    86: {'word3': 'Pluto-Quincunx-Chiron', 'cat': ['Money']},
    87: {'word3': 'Pluto-Parallel-Chiron', 'cat': ['Money']},
    88: {'word3': 'Pluto-Contraparallel-Chiron', 'cat': ['Money']},
    89: {'word3': 'Pluto-Conjunct-Ceres', 'cat': ['Money']},
    90: {'word3': 'Pluto-Trine-Ceres', 'cat': ['Money']},
    91: {'word3': 'Pluto-Quincunx-Ceres', 'cat': ['Money']},
    92: {'word3': 'Pluto-Parallel-Ceres', 'cat': ['Money']},
    93: {'word3': 'Pluto-Contraparallel-Ceres', 'cat': ['Money']},
    94: {'word3': 'Pluto-Conjunct-Sedna', 'cat': ['Money']},
    95: {'word3': 'Pluto-Trine-Sedna', 'cat': ['Money']},
    96: {'word3': 'Pluto-Quincunx-Sedna', 'cat': ['Money']},
    97: {'word3': 'Pluto-Parallel-Sedna', 'cat': ['Money']},
    98: {'word3': 'Pluto-Contraparallel-Sedna', 'cat': ['Money']},
    99: {'word3': 'Pluto-Conjunct-Odin', 'cat': ['Money']},
    100: {'word3': 'Pluto-Trine-Odin', 'cat': ['Money']},
    101: {'word3': 'Pluto-Quincunx-Odin', 'cat': ['Money']},
    102: {'word3': 'Pluto-Parallel-Odin', 'cat': ['Money']},
    103: {'word3': 'Pluto-Contraparallel-Odin', 'cat': ['Money']},
    104: {'word3': 'Pluto-Conjunct-Midas', 'cat': ['Money']},
    105: {'word3': 'Pluto-Trine-Midas', 'cat': ['Money']},
    106: {'word3': 'Pluto-Quincunx-Midas', 'cat': ['Money']},
    107: {'word3': 'Pluto-Parallel-Midas', 'cat': ['Money']},
    108: {'word3': 'Pluto-Contraparallel-Midas', 'cat': ['Money']},
    109: {'word3': 'Pluto-Conjunct-Quaoar', 'cat': ['Money']},
    110: {'word3': 'Pluto-Trine-Quaoar', 'cat': ['Money']},
    111: {'word3': 'Pluto-Quincunx-Quaoar', 'cat': ['Money']},
    112: {'word3': 'Pluto-Parallel-Quaoar', 'cat': ['Money']},
    113: {'word3': 'Pluto-Contraparallel-Quaoar', 'cat': ['Money']},
    114: {'word3': 'Pluto-Conjunct-ErisUB313', 'cat': ['Money']},
    115: {'word3': 'Pluto-Trine-ErisUB313', 'cat': ['Money']},
    116: {'word3': 'Pluto-Quincunx-ErisUB313', 'cat': ['Money']},
    117: {'word3': 'Pluto-Parallel-ErisUB313', 'cat': ['Money']},
    118: {'word3': 'Pluto-Contraparallel-ErisUB313', 'cat': ['Money']},
    119: {'word3': 'Chiron-Conjunct-Ceres', 'cat': ['Money']},
    120: {'word3': 'Chiron-Trine-Ceres', 'cat': ['Money']},
    121: {'word3': 'Chiron-Quincunx-Ceres', 'cat': ['Money']},
    122: {'word3': 'Chiron-Parallel-Ceres', 'cat': ['Money']},
    123: {'word3': 'Chiron-Contraparallel-Ceres', 'cat': ['Money']},
    124: {'word3': 'Chiron-Conjunct-Sedna', 'cat': ['Money']},
    125: {'word3': 'Chiron-Trine-Sedna', 'cat': ['Money']},
    126: {'word3': 'Chiron-Quincunx-Sedna', 'cat': ['Money']},
    127: {'word3': 'Chiron-Parallel-Sedna', 'cat': ['Money']},
    128: {'word3': 'Chiron-Contraparallel-Sedna', 'cat': ['Money']},
    129: {'word3': 'Chiron-Conjunct-Odin', 'cat': ['Money']},
    130: {'word3': 'Chiron-Trine-Odin', 'cat': ['Money']},
    131: {'word3': 'Chiron-Quincunx-Odin', 'cat': ['Money']},
    132: {'word3': 'Chiron-Parallel-Odin', 'cat': ['Money']},
    133: {'word3': 'Chiron-Contraparallel-Odin', 'cat': ['Money']},
    134: {'word3': 'Chiron-Conjunct-Midas', 'cat': ['Money']},
    135: {'word3': 'Chiron-Trine-Midas', 'cat': ['Money']},
    136: {'word3': 'Chiron-Quincunx-Midas', 'cat': ['Money']},
    137: {'word3': 'Chiron-Parallel-Midas', 'cat': ['Money']},
    138: {'word3': 'Chiron-Contraparallel-Midas', 'cat': ['Money']},
    139: {'word3': 'Chiron-Conjunct-Quaoar', 'cat': ['Money']},
    140: {'word3': 'Chiron-Trine-Quaoar', 'cat': ['Money']},
    141: {'word3': 'Chiron-Quincunx-Quaoar', 'cat': ['Money']},
    142: {'word3': 'Chiron-Parallel-Quaoar', 'cat': ['Money']},
    143: {'word3': 'Chiron-Contraparallel-Quaoar', 'cat': ['Money']},
    144: {'word3': 'Chiron-Conjunct-ErisUB313', 'cat': ['Money']},
    145: {'word3': 'Chiron-Trine-ErisUB313', 'cat': ['Money']},
    146: {'word3': 'Chiron-Quincunx-ErisUB313', 'cat': ['Money']},
    147: {'word3': 'Chiron-Parallel-ErisUB313', 'cat': ['Money']},
    148: {'word3': 'Chiron-Contraparallel-ErisUB313', 'cat': ['Money']},
    149: {'word3': 'Ceres-Conjunct-Sedna', 'cat': ['Money']},
    150: {'word3': 'Ceres-Trine-Sedna', 'cat': ['Money']},
    151: {'word3': 'Ceres-Quincunx-Sedna', 'cat': ['Money']},
    152: {'word3': 'Ceres-Parallel-Sedna', 'cat': ['Money']},
    153: {'word3': 'Ceres-Contraparallel-Sedna', 'cat': ['Money']},
    154: {'word3': 'Ceres-Conjunct-Odin', 'cat': ['Money']},
    155: {'word3': 'Ceres-Trine-Odin', 'cat': ['Money']},
    156: {'word3': 'Ceres-Quincunx-Odin', 'cat': ['Money']},
    157: {'word3': 'Ceres-Parallel-Odin', 'cat': ['Money']},
    158: {'word3': 'Ceres-Contraparallel-Odin', 'cat': ['Money']},
    159: {'word3': 'Ceres-Conjunct-Midas', 'cat': ['Money']},
    160: {'word3': 'Ceres-Trine-Midas', 'cat': ['Money']},
    161: {'word3': 'Ceres-Quincunx-Midas', 'cat': ['Money']},
    162: {'word3': 'Ceres-Parallel-Midas', 'cat': ['Money']},
    163: {'word3': 'Ceres-Contraparallel-Midas', 'cat': ['Money']},
    164: {'word3': 'Ceres-Conjunct-Quaoar', 'cat': ['Money']},
    165: {'word3': 'Ceres-Trine-Quaoar', 'cat': ['Money']},
    166: {'word3': 'Ceres-Quincunx-Quaoar', 'cat': ['Money']},
    167: {'word3': 'Ceres-Parallel-Quaoar', 'cat': ['Money']},
    168: {'word3': 'Ceres-Contraparallel-Quaoar', 'cat': ['Money']},
    169: {'word3': 'Ceres-Conjunct-ErisUB313', 'cat': ['Money']},
    170: {'word3': 'Ceres-Trine-ErisUB313', 'cat': ['Money']},
    171: {'word3': 'Ceres-Quincunx-ErisUB313', 'cat': ['Money']},
    172: {'word3': 'Ceres-Parallel-ErisUB313', 'cat': ['Money']},
    173: {'word3': 'Ceres-Contraparallel-ErisUB313', 'cat': ['Money']},
    174: {'word3': 'Sedna-Conjunct-Odin', 'cat': ['Money']},
    175: {'word3': 'Sedna-Trine-Odin', 'cat': ['Money']},
    176: {'word3': 'Sedna-Quincunx-Odin', 'cat': ['Money']},
    177: {'word3': 'Sedna-Parallel-Odin', 'cat': ['Money']},
    178: {'word3': 'Sedna-Contraparallel-Odin', 'cat': ['Money']},
    179: {'word3': 'Sedna-Conjunct-Midas', 'cat': ['Money']},
    180: {'word3': 'Sedna-Trine-Midas', 'cat': ['Money']},
    181: {'word3': 'Sedna-Quincunx-Midas', 'cat': ['Money']},
    182: {'word3': 'Sedna-Parallel-Midas', 'cat': ['Money']},
    183: {'word3': 'Sedna-Contraparallel-Midas', 'cat': ['Money']},
    184: {'word3': 'Sedna-Conjunct-Quaoar', 'cat': ['Money']},
    185: {'word3': 'Sedna-Trine-Quaoar', 'cat': ['Money']},
    186: {'word3': 'Sedna-Quincunx-Quaoar', 'cat': ['Money']},
    187: {'word3': 'Sedna-Parallel-Quaoar', 'cat': ['Money']},
    188: {'word3': 'Sedna-Contraparallel-Quaoar', 'cat': ['Money']},
    189: {'word3': 'Sedna-Conjunct-ErisUB313', 'cat': ['Money']},
    190: {'word3': 'Sedna-Trine-ErisUB313', 'cat': ['Money']},
    191: {'word3': 'Sedna-Quincunx-ErisUB313', 'cat': ['Money']},
    192: {'word3': 'Sedna-Parallel-ErisUB313', 'cat': ['Money']},
    193: {'word3': 'Sedna-Contraparallel-ErisUB313', 'cat': ['Money']},
    194: {'word3': 'Odin-Conjunct-Midas', 'cat': ['Money']},
    195: {'word3': 'Odin-Trine-Midas', 'cat': ['Money']},
    196: {'word3': 'Odin-Quincunx-Midas', 'cat': ['Money']},
    197: {'word3': 'Odin-Parallel-Midas', 'cat': ['Money']},
    198: {'word3': 'Odin-Contraparallel-Midas', 'cat': ['Money']},
    199: {'word3': 'Odin-Conjunct-Quaoar', 'cat': ['Money']},
    200: {'word3': 'Odin-Trine-Quaoar', 'cat': ['Money']},
    201: {'word3': 'Odin-Quincunx-Quaoar', 'cat': ['Money']},
    202: {'word3': 'Odin-Parallel-Quaoar', 'cat': ['Money']},
    203: {'word3': 'Odin-Contraparallel-Quaoar', 'cat': ['Money']},
    204: {'word3': 'Odin-Conjunct-ErisUB313', 'cat': ['Money']},
    205: {'word3': 'Odin-Trine-ErisUB313', 'cat': ['Money']},
    206: {'word3': 'Odin-Quincunx-ErisUB313', 'cat': ['Money']},
    207: {'word3': 'Odin-Parallel-ErisUB313', 'cat': ['Money']},
    208: {'word3': 'Odin-Contraparallel-ErisUB313', 'cat': ['Money']},
    209: {'word3': 'Midas-Conjunct-Quaoar', 'cat': ['Money']},
    210: {'word3': 'Midas-Trine-Quaoar', 'cat': ['Money']},
    211: {'word3': 'Midas-Quincunx-Quaoar', 'cat': ['Money']},
    212: {'word3': 'Midas-Parallel-Quaoar', 'cat': ['Money']},
    213: {'word3': 'Midas-Contraparallel-Quaoar', 'cat': ['Money']},
    214: {'word3': 'Midas-Conjunct-ErisUB313', 'cat': ['Money']},
    215: {'word3': 'Midas-Trine-ErisUB313', 'cat': ['Money']},
    216: {'word3': 'Midas-Quincunx-ErisUB313', 'cat': ['Money']},
    217: {'word3': 'Midas-Parallel-ErisUB313', 'cat': ['Money']},
    218: {'word3': 'Midas-Contraparallel-ErisUB313', 'cat': ['Money']},
    219: {'word3': 'Quaoar-Conjunct-ErisUB313', 'cat': ['Money']},
    220: {'word3': 'Quaoar-Trine-ErisUB313', 'cat': ['Money']},
    221: {'word3': 'Quaoar-Quincunx-ErisUB313', 'cat': ['Money']},
    222: {'word3': 'Quaoar-Parallel-ErisUB313', 'cat': ['Money']},
    223: {'word3': 'Quaoar-Contraparallel-ErisUB313', 'cat': ['Money']},
    # the drama
    224: {'word3': 'Venus-Opposed-Neptune', 'cat': ['Drama'] },
    225: {'word3': 'Venus-Square-Neptune', 'cat': ['Drama'] },
    226: {'word3': 'Venus-Opposed-Pluto', 'cat': ['Drama'] },
    227: {'word3': 'Venus-Square-Pluto', 'cat': ['Drama'] },
    228: {'word3': 'Venus-Opposed-Chiron', 'cat': ['Drama'] },
    229: {'word3': 'Venus-Square-Chiron', 'cat': ['Drama'] },
    230: {'word3': 'Venus-Opposed-Ceres', 'cat': ['Drama'] },
    231: {'word3': 'Venus-Square-Ceres', 'cat': ['Drama'] },
    232: {'word3': 'Venus-Opposed-Sedna', 'cat': ['Drama'] },
    233: {'word3': 'Venus-Square-Sedna', 'cat': ['Drama'] },
    234: {'word3': 'Venus-Opposed-Odin', 'cat': ['Drama'] },
    235: {'word3': 'Venus-Square-Odin', 'cat': ['Drama'] },
    236: {'word3': 'Venus-Opposed-Midas', 'cat': ['Drama'] },
    237: {'word3': 'Venus-Square-Midas', 'cat': ['Drama'] },
    238: {'word3': 'Venus-Opposed-Quaoar', 'cat': ['Drama'] },
    239: {'word3': 'Venus-Square-Quaoar', 'cat': ['Drama'] },
    240: {'word3': 'Venus-Opposed-ErisUB313', 'cat': ['Drama'] },
    241: {'word3': 'Venus-Square-ErisUB313', 'cat': ['Drama'] },
    242: {'word3': 'Neptune-Opposed-Pluto', 'cat': ['Drama'] },
    243: {'word3': 'Neptune-Square-Pluto', 'cat': ['Drama'] },
    244: {'word3': 'Neptune-Opposed-Chiron', 'cat': ['Drama'] },
    245: {'word3': 'Neptune-Square-Chiron', 'cat': ['Drama'] },
    246: {'word3': 'Neptune-Opposed-Ceres', 'cat': ['Drama'] },
    247: {'word3': 'Neptune-Square-Ceres', 'cat': ['Drama'] },
    248: {'word3': 'Neptune-Opposed-Sedna', 'cat': ['Drama'] },
    249: {'word3': 'Neptune-Square-Sedna', 'cat': ['Drama'] },
    250: {'word3': 'Neptune-Opposed-Odin', 'cat': ['Drama'] },
    251: {'word3': 'Neptune-Square-Odin', 'cat': ['Drama'] },
    252: {'word3': 'Neptune-Opposed-Midas', 'cat': ['Drama'] },
    253: {'word3': 'Neptune-Square-Midas', 'cat': ['Drama'] },
    254: {'word3': 'Neptune-Opposed-Quaoar', 'cat': ['Drama'] },
    255: {'word3': 'Neptune-Square-Quaoar', 'cat': ['Drama'] },
    256: {'word3': 'Neptune-Opposed-ErisUB313', 'cat': ['Drama'] },
    257: {'word3': 'Neptune-Square-ErisUB313', 'cat': ['Drama'] },
    258: {'word3': 'Pluto-Opposed-Chiron', 'cat': ['Drama'] },
    259: {'word3': 'Pluto-Square-Chiron', 'cat': ['Drama'] },
    260: {'word3': 'Pluto-Opposed-Ceres', 'cat': ['Drama'] },
    261: {'word3': 'Pluto-Square-Ceres', 'cat': ['Drama'] },
    262: {'word3': 'Pluto-Opposed-Sedna', 'cat': ['Drama'] },
    263: {'word3': 'Pluto-Square-Sedna', 'cat': ['Drama'] },
    264: {'word3': 'Pluto-Opposed-Odin', 'cat': ['Drama'] },
    265: {'word3': 'Pluto-Square-Odin', 'cat': ['Drama'] },
    266: {'word3': 'Pluto-Opposed-Midas', 'cat': ['Drama'] },
    267: {'word3': 'Pluto-Square-Midas', 'cat': ['Drama'] },
    268: {'word3': 'Pluto-Opposed-Quaoar', 'cat': ['Drama'] },
    269: {'word3': 'Pluto-Square-Quaoar', 'cat': ['Drama'] },
    270: {'word3': 'Pluto-Opposed-ErisUB313', 'cat': ['Drama'] },
    271: {'word3': 'Pluto-Square-ErisUB313', 'cat': ['Drama'] },
    272: {'word3': 'Chiron-Opposed-Ceres', 'cat': ['Drama'] },
    273: {'word3': 'Chiron-Square-Ceres', 'cat': ['Drama'] },
    274: {'word3': 'Chiron-Opposed-Sedna', 'cat': ['Drama'] },
    275: {'word3': 'Chiron-Square-Sedna', 'cat': ['Drama'] },
    276: {'word3': 'Chiron-Opposed-Odin', 'cat': ['Drama'] },
    277: {'word3': 'Chiron-Square-Odin', 'cat': ['Drama'] },
    278: {'word3': 'Chiron-Opposed-Midas', 'cat': ['Drama'] },
    279: {'word3': 'Chiron-Square-Midas', 'cat': ['Drama'] },
    280: {'word3': 'Chiron-Opposed-Quaoar', 'cat': ['Drama'] },
    281: {'word3': 'Chiron-Square-Quaoar', 'cat': ['Drama'] },
    282: {'word3': 'Chiron-Opposed-ErisUB313', 'cat': ['Drama'] },
    283: {'word3': 'Chiron-Square-ErisUB313', 'cat': ['Drama'] },
    284: {'word3': 'Ceres-Opposed-Sedna', 'cat': ['Drama'] },
    285: {'word3': 'Ceres-Square-Sedna', 'cat': ['Drama'] },
    286: {'word3': 'Ceres-Opposed-Odin', 'cat': ['Drama'] },
    287: {'word3': 'Ceres-Square-Odin', 'cat': ['Drama'] },
    288: {'word3': 'Ceres-Opposed-Midas', 'cat': ['Drama'] },
    289: {'word3': 'Ceres-Square-Midas', 'cat': ['Drama'] },
    290: {'word3': 'Ceres-Opposed-Quaoar', 'cat': ['Drama'] },
    291: {'word3': 'Ceres-Square-Quaoar', 'cat': ['Drama'] },
    292: {'word3': 'Ceres-Opposed-ErisUB313', 'cat': ['Drama'] },
    293: {'word3': 'Ceres-Square-ErisUB313', 'cat': ['Drama'] },
    294: {'word3': 'Sedna-Opposed-Odin', 'cat': ['Drama'] },
    295: {'word3': 'Sedna-Square-Odin', 'cat': ['Drama'] },
    296: {'word3': 'Sedna-Opposed-Midas', 'cat': ['Drama'] },
    297: {'word3': 'Sedna-Square-Midas', 'cat': ['Drama'] },
    298: {'word3': 'Sedna-Opposed-Quaoar', 'cat': ['Drama'] },
    299: {'word3': 'Sedna-Square-Quaoar', 'cat': ['Drama'] },
    300: {'word3': 'Sedna-Opposed-ErisUB313', 'cat': ['Drama'] },
    301: {'word3': 'Sedna-Square-ErisUB313', 'cat': ['Drama'] },
    302: {'word3': 'Odin-Opposed-Midas', 'cat': ['Drama'] },
    303: {'word3': 'Odin-Square-Midas', 'cat': ['Drama'] },
    304: {'word3': 'Odin-Opposed-Quaoar', 'cat': ['Drama'] },
    305: {'word3': 'Odin-Square-Quaoar', 'cat': ['Drama'] },
    306: {'word3': 'Odin-Opposed-ErisUB313', 'cat': ['Drama'] },
    307: {'word3': 'Odin-Square-ErisUB313', 'cat': ['Drama'] },
    308: {'word3': 'Midas-Opposed-Quaoar', 'cat': ['Drama'] },
    309: {'word3': 'Midas-Square-Quaoar', 'cat': ['Drama'] },
    310: {'word3': 'Midas-Opposed-ErisUB313', 'cat': ['Drama'] },
    311: {'word3': 'Midas-Square-ErisUB313', 'cat': ['Drama'] },
    312: {'word3': 'Quaoar-Opposed-ErisUB313', 'cat': ['Drama'] },
    313: {'word3': 'Quaoar-Square-ErisUB313', 'cat': ['Drama'] },
    314: {'word3': 'Venus-Opposed-Saturn', 'cat': ['Drama'] },
    315: {'word3': 'Venus-Square-Saturn', 'cat': ['Drama'] },
    316: {'word3': 'Venus-Quincunx-Saturn', 'cat': ['Drama'] },
    317: {'word3': 'Venus-Contraparallel-Saturn', 'cat': ['Drama'] },
    318: {'word3': 'Saturn-Opposed-Neptune', 'cat': ['Drama'] },
    319: {'word3': 'Saturn-Square-Neptune', 'cat': ['Drama'] },
    320: {'word3': 'Saturn-Quincunx-Neptune', 'cat': ['Drama'] },
    321: {'word3': 'Saturn-Contraparallel-Neptune', 'cat': ['Drama'] },
    322: {'word3': 'Saturn-Opposed-Pluto', 'cat': ['Drama'] },
    323: {'word3': 'Saturn-Square-Pluto', 'cat': ['Drama'] },
    324: {'word3': 'Saturn-Quincunx-Pluto', 'cat': ['Drama'] },
    325: {'word3': 'Saturn-Contraparallel-Pluto', 'cat': ['Drama'] },
    326: {'word3': 'Saturn-Opposed-Chiron', 'cat': ['Drama'] },
    327: {'word3': 'Saturn-Square-Chiron', 'cat': ['Drama'] },
    328: {'word3': 'Saturn-Quincunx-Chiron', 'cat': ['Drama'] },
    329: {'word3': 'Saturn-Contraparallel-Chiron', 'cat': ['Drama'] },
    330: {'word3': 'Saturn-Opposed-Ceres', 'cat': ['Drama'] },
    331: {'word3': 'Saturn-Square-Ceres', 'cat': ['Drama'] },
    332: {'word3': 'Saturn-Quincunx-Ceres', 'cat': ['Drama'] },
    333: {'word3': 'Saturn-Contraparallel-Ceres', 'cat': ['Drama'] },
    334: {'word3': 'Saturn-Opposed-Sedna', 'cat': ['Drama'] },
    335: {'word3': 'Saturn-Square-Sedna', 'cat': ['Drama'] },
    336: {'word3': 'Saturn-Quincunx-Sedna', 'cat': ['Drama'] },
    337: {'word3': 'Saturn-Contraparallel-Sedna', 'cat': ['Drama'] },
    338: {'word3': 'Saturn-Opposed-Odin', 'cat': ['Drama'] },
    339: {'word3': 'Saturn-Square-Odin', 'cat': ['Drama'] },
    340: {'word3': 'Saturn-Quincunx-Odin', 'cat': ['Drama'] },
    341: {'word3': 'Saturn-Contraparallel-Odin', 'cat': ['Drama'] },
    342: {'word3': 'Saturn-Opposed-Midas', 'cat': ['Drama'] },
    343: {'word3': 'Saturn-Square-Midas', 'cat': ['Drama'] },
    344: {'word3': 'Saturn-Quincunx-Midas', 'cat': ['Drama'] },
    345: {'word3': 'Saturn-Contraparallel-Midas', 'cat': ['Drama'] },
    346: {'word3': 'Saturn-Opposed-Quaoar', 'cat': ['Drama'] },
    347: {'word3': 'Saturn-Square-Quaoar', 'cat': ['Drama'] },
    348: {'word3': 'Saturn-Quincunx-Quaoar', 'cat': ['Drama'] },
    349: {'word3': 'Saturn-Contraparallel-Quaoar', 'cat': ['Drama'] },
    350: {'word3': 'Saturn-Opposed-ErisUB313', 'cat': ['Drama'] },
    351: {'word3': 'Saturn-Square-ErisUB313', 'cat': ['Drama'] },
    352: {'word3': 'Saturn-Quincunx-ErisUB313', 'cat': ['Drama'] },
    353: {'word3': 'Saturn-Contraparallel-ErisUB313', 'cat': ['Drama'] }
}

# financial planets - making angles to a Saturnian planet
# Saturnian Planets: Saturn and its midpoints, Sedna and its midpoints, Sappho


# the order: #'Sun','Moon','Mercury','Venus','Mars','Jupiter','Saturn','Uranus','Neptune','Pluto','NorthNode','SouthNode','Chiron','Ceres','Pallas','Juno','Vesta','Eros','Amor','Sappho','Lilith','SunMoonMidpoint','Fortune','Ascendant','II','III','IV','V','VI','Descendant','VIII','IX','Midheaven','XI','XII'


# import ASTROLOGYmagi as m
# locs = m.xyLoc
xyLoc = {
        0: {'start-deg': 0, 'end-deg': 30, 'minXY': [80, 340], 'maxXY': [120, 475]},
        1: {'start-deg': 30, 'end-deg': 60, 'minXY': [120, 475], 'maxXY': [212, 565]},
        2: {'start-deg': 60, 'end-deg': 90, 'minXY': [212, 565], 'maxXY': [340, 600]},
        3: {'start-deg': 90, 'end-deg': 120, 'minXY': [340, 600], 'maxXY': [470, 575]},
        4: {'start-deg': 120, 'end-deg': 150, 'minXY': [470, 575], 'maxXY': [570, 480]},
        5: {'start-deg': 150, 'end-deg': 180, 'minXY': [570, 480], 'maxXY': [600, 340]},
        6: {'start-deg': 180, 'end-deg': 210, 'minXY': [600, 340], 'maxXY': [570, 200]},
        7: {'start-deg': 210, 'end-deg': 240, 'minXY': [570, 200], 'maxXY': [470, 110]},
        8: {'start-deg': 240, 'end-deg': 270, 'minXY': [470, 110], 'maxXY': [340, 80]},
        9: {'start-deg': 270, 'end-deg': 300, 'minXY': [340, 80], 'maxXY': [210, 105]},
        10: {'start-deg': 300, 'end-deg': 330, 'minXY': [210, 105], 'maxXY': [113, 200]},
        11: {'start-deg': 330, 'end-deg': 360, 'minXY': [113, 200], 'maxXY': [80, 340]}
    }


"""
    0: "Venus",
    1: "Neptune",
    2: "Pluto",
    3: "Chiron",
    4: "Ceres",
    5: "Sedna",
    6: "Odin",
    7: "Midas",
    8: "Quaoar",
    9: "ErisUB313"
"""



"""










#-------------------------------
# Re-Number - the array lists
# import ASTROLOGYfunctions as aa
# aa.parse3wordsReNumber(start_with_num=224)


"""






# import ASTROLOGYmagi as m


