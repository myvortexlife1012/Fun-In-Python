#v6
"""
import ProgressBAR as pb
pb.ProgressBAR(.1)

Required:
pip install update_progress  # gives you a text moving percentage, each time you run it
"""

def ProgressBAR(num=.1):
    import time, sys

    # update_progress() : Displays or updates a console progress bar
    ## Accepts a float between 0 and 1. Any int will be converted to a float.
    ## A value under 0 represents a 'halt'.
    ## A value at 1 or bigger represents 100%
    def update_progress(progress):
        barLength = 10  # Modify this to change the length of the progress bar
        status = ""
        if isinstance(progress, int):
            progress = float(progress)
        if not isinstance(progress, float):
            progress = 0
            status = "error: progress var must be float\r\n"
        if progress < 0:
            progress = 0
            status = "Halt...\r\n"
        if progress >= 1:
            progress = 1
            status = "Done...\r\n"
        block = int(round(barLength * progress))
        text = "\rPercent: [{0}] {1}% {2}".format("#" * block + "-" * (barLength - block), progress * 100, status)
        sys.stdout.write(text)
        sys.stdout.flush()

    #The Progress Bar - text - in console - updates for you
    print("")
    print("\n\n\n\n\n\n\n\n\n\n\n\n")
    update_progress(num)

    #print("progress : 0->1")
    """
    update_progress(0 / 100.0)
    time.sleep(0.2)
    update_progress(10 / 100.0)
    time.sleep(0.4)
    update_progress(25 / 100.0)
    time.sleep(0.4)
    update_progress(50 / 100.0)
    time.sleep(0.4)
    update_progress(75 / 100.0)
    time.sleep(0.4)
    update_progress(90 / 100.0)
    time.sleep(0.4)
    update_progress(100 / 100.0)
"""

