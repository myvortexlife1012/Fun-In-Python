#run in the conda prompt:
# python repeat-bg.py

#add in a way so it only gets a new background if the right arrow is pressed
import RepeatSoOFTEN as repeat
repeat.RepeatSoOFTEN()