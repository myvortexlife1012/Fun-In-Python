#run in the conda prompt:
#python clipboard-read.py

import ClipboardChangesREAD as clipread
clipread.ClipboardChangesREAD()
